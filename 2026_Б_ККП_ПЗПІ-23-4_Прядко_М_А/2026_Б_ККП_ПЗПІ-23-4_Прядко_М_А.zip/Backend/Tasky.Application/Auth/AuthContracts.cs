namespace Tasky.Application.Auth;

public sealed record RegisterRequest(string UserName, string Email, string Password);
public sealed record LoginRequest(string UserNameOrEmail, string Password);
public sealed record RefreshTokenRequest(string RefreshToken);
public sealed record RevokeRefreshTokenRequest(string RefreshToken);
public sealed record ConfirmEmailRequest(string UserId, string Token);
public sealed record ForgotPasswordRequest(string Email);
public sealed record ResetPasswordRequest(string Email, string Token, string NewPassword);
public sealed record AuthResponse(string AccessToken, string RefreshToken, UserResponse User);
public sealed record UserResponse(string Id, string UserName, string Email, bool EmailConfirmed);
public sealed record TokenResponse(string Token);
