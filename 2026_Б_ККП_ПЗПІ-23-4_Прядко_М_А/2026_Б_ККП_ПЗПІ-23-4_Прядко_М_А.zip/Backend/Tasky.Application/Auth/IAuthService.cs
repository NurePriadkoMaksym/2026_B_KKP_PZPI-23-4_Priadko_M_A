using Tasky.Application.Common;

namespace Tasky.Application.Auth;

public interface IAuthService
{
    Task<Result<AuthResponse>> RegisterAsync(RegisterRequest request);
    Task<Result<AuthResponse>> LoginAsync(LoginRequest request);
    Task<Result<AuthResponse>> RefreshAsync(RefreshTokenRequest request);
    Task<Result> RevokeRefreshTokenAsync(string userId, RevokeRefreshTokenRequest request);
    Task<Result<TokenResponse>> CreateEmailConfirmationTokenAsync(string email);
    Task<Result> ConfirmEmailAsync(ConfirmEmailRequest request);
    Task<Result<TokenResponse>> CreatePasswordResetTokenAsync(ForgotPasswordRequest request);
    Task<Result> ResetPasswordAsync(ResetPasswordRequest request);
}
