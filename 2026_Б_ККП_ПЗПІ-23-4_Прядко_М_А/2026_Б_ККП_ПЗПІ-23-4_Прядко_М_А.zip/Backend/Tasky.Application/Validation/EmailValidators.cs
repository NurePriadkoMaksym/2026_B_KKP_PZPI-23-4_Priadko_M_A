using FluentValidation;
using Tasky.Application.Emails;

namespace Tasky.Application.Validation;

public sealed class SendTestEmailRequestValidator : AbstractValidator<SendTestEmailRequest>
{
    public SendTestEmailRequestValidator()
    {
        RuleFor(x => x.To).NotEmpty().EmailAddress();
    }
}
