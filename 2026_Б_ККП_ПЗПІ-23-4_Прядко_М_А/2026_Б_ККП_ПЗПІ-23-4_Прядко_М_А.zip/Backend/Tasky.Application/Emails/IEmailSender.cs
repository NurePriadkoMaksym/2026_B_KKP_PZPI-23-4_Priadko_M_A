namespace Tasky.Application.Emails;

public sealed record EmailMessage(string To, string Subject, string TextBody, string? HtmlBody = null);
public sealed record EmailDeliveryResult(bool Delivered, string Status, string? Error = null);
public sealed record SendTestEmailRequest(string To);
public sealed record InvitationEmailDeliveryResult(string InvitationLink, EmailDeliveryResult Delivery);

public interface IEmailSender
{
    Task<EmailDeliveryResult> SendAsync(EmailMessage message, CancellationToken cancellationToken = default);
}

public interface IInvitationEmailService
{
    Task<InvitationEmailDeliveryResult> SendTeamInvitationAsync(
        string recipientEmail,
        string teamName,
        string rawToken,
        DateTime expiresAtUtc,
        CancellationToken cancellationToken = default);
}
