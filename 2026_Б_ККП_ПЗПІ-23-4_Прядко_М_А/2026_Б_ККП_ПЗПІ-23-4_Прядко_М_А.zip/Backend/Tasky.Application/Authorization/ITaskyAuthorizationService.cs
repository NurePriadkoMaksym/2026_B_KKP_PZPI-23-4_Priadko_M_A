using Tasky.Domain;

namespace Tasky.Application.Authorization;

public interface ITaskyAuthorizationService
{
    Task<bool> IsTeamMemberAsync(Guid teamId, string userId);
    Task<bool> IsTeamManagerAsync(Guid teamId, string userId);
    Task<bool> IsTeamOwnerAsync(Guid teamId, string userId);
    Task<bool> CanAccessProjectAsync(Guid projectId, string userId);
    Task<bool> CanManageProjectAsync(Guid projectId, string userId);
    Task<bool> CanAccessTaskAsync(Guid taskId, string userId);
    Task<TeamRole?> GetTeamRoleAsync(Guid teamId, string userId);
}
