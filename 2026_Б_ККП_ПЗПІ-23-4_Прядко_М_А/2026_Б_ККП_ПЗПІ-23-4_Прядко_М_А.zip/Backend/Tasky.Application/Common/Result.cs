namespace Tasky.Application.Common;

public sealed record Error(string Code, string Message);

public sealed class Result<T>
{
    private Result(T? value, Error? error, int statusCode)
    {
        Value = value;
        Error = error;
        StatusCode = statusCode;
    }

    public T? Value { get; }
    public Error? Error { get; }
    public int StatusCode { get; }
    public bool Succeeded => Error is null;

    public static Result<T> Ok(T value) => new(value, null, 200);
    public static Result<T> Created(T value) => new(value, null, 201);
    public static Result<T> Fail(string code, string message, int statusCode) => new(default, new Error(code, message), statusCode);
}

public sealed class Result
{
    private Result(Error? error, int statusCode)
    {
        Error = error;
        StatusCode = statusCode;
    }

    public Error? Error { get; }
    public int StatusCode { get; }
    public bool Succeeded => Error is null;

    public static Result Ok() => new(null, 204);
    public static Result Fail(string code, string message, int statusCode) => new(new Error(code, message), statusCode);
}
