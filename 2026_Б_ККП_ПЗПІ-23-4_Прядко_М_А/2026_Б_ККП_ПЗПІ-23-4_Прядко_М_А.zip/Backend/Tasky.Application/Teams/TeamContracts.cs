using Tasky.Domain;

namespace Tasky.Application.Teams;

public sealed record CreateTeamRequest(string Name, string? Description);
public sealed record TeamResponse(Guid Id, string Name, string? Description, TeamRole CurrentUserRole, int MembersCount);
public sealed record InviteUserRequest(string? UserName, string? Email);
public sealed record InvitationResponse(
    Guid Id,
    Guid TeamId,
    string? InvitedUserName,
    string? InvitedEmail,
    InvitationStatus Status,
    DateTime ExpiresAtUtc,
    string Token,
    string InvitationLink,
    bool IsTargeted);
public sealed record PendingInvitationResponse(
    Guid Id,
    Guid TeamId,
    string TeamName,
    string InvitedByUserId,
    DateTime CreatedAtUtc,
    DateTime ExpiresAtUtc);
public sealed record AcceptInvitationRequest(string Token);
public sealed record TeamMemberResponse(string UserId, string UserName, string Email, TeamRole Role, DateTime JoinedAtUtc);
public sealed record ChangeMemberRoleRequest(TeamRole Role);
