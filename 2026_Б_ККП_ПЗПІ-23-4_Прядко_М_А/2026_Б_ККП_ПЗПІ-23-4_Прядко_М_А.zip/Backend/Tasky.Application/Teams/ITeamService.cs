using Tasky.Application.Common;

namespace Tasky.Application.Teams;

public interface ITeamService
{
    Task<Result<TeamResponse>> CreateAsync(string userId, CreateTeamRequest request);
    Task<Result<IReadOnlyList<TeamResponse>>> GetMineAsync(string userId);
    Task<Result<TeamResponse>> GetByIdAsync(string userId, Guid teamId);
    Task<Result<IReadOnlyList<TeamMemberResponse>>> GetMembersAsync(string userId, Guid teamId);
    Task<Result<InvitationResponse>> InviteAsync(string userId, Guid teamId, InviteUserRequest request);
    Task<Result<IReadOnlyList<PendingInvitationResponse>>> GetMyPendingInvitationsAsync(string userId);
    Task<Result> AcceptInvitationAsync(string userId, AcceptInvitationRequest request);
    Task<Result> AcceptInvitationAsync(string userId, Guid invitationId);
    Task<Result> ChangeMemberRoleAsync(string userId, Guid teamId, string memberUserId, ChangeMemberRoleRequest request);
    Task<Result> RemoveMemberAsync(string userId, Guid teamId, string memberUserId);
    Task<Result> DeleteAsync(string userId, Guid teamId);
}
