using Tasky.Application.Common;

namespace Tasky.Application.Projects;

public interface IProjectService
{
    Task<Result<ProjectResponse>> CreateAsync(string userId, Guid teamId, CreateProjectRequest request);
    Task<Result<IReadOnlyList<ProjectResponse>>> GetTeamProjectsAsync(string userId, Guid teamId);
    Task<Result<KanbanColumnResponse>> AddColumnAsync(string userId, Guid projectId, CreateKanbanColumnRequest request);
    Task<Result> DeleteAsync(string userId, Guid projectId);
}
