using Tasky.Domain;

namespace Tasky.Application.Projects;

public sealed record CreateProjectRequest(string Name, string? Description);
public sealed record ProjectResponse(Guid Id, Guid TeamId, string Name, string? Description, IReadOnlyList<KanbanColumnResponse> Columns);
public sealed record CreateKanbanColumnRequest(string Name, int Position, WorkItemStatus MappedStatus);
public sealed record KanbanColumnResponse(Guid Id, string Name, int Position, WorkItemStatus MappedStatus);
