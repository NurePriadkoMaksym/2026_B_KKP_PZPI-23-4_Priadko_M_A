using Tasky.Domain;

namespace Tasky.Application.Tasks;

public sealed record CreateTaskRequest(
    Guid ColumnId,
    string Title,
    string? Description,
    WorkItemPriority Priority,
    DateTime? DeadlineUtc,
    IReadOnlyList<string> AssigneeUserIds,
    IReadOnlyList<Guid> LabelIds);

public sealed record UpdateTaskRequest(
    Guid? ColumnId,
    string? Title,
    string? Description,
    WorkItemPriority? Priority,
    WorkItemStatus? Status,
    DateTime? DeadlineUtc,
    IReadOnlyList<string>? AssigneeUserIds,
    IReadOnlyList<Guid>? LabelIds);

public sealed record TaskSearchRequest(
    string? Query,
    string? AssigneeUserId,
    WorkItemPriority? Priority,
    WorkItemStatus? Status,
    Guid? LabelId,
    DateTime? DeadlineFromUtc,
    DateTime? DeadlineToUtc,
    int Page = 1,
    int PageSize = 25);

public sealed record TaskResponse(
    Guid Id,
    Guid ProjectId,
    Guid ColumnId,
    string Title,
    string? Description,
    WorkItemPriority Priority,
    WorkItemStatus Status,
    DateTime? DeadlineUtc,
    IReadOnlyList<string> AssigneeUserIds,
    IReadOnlyList<TaskLabelResponse> Labels,
    int CommentsCount,
    int AttachmentsCount,
    DateTime CreatedAtUtc,
    DateTime? UpdatedAtUtc);

public sealed record CreateTaskCommentRequest(string Body);
public sealed record TaskCommentResponse(Guid Id, Guid TaskItemId, string AuthorUserId, string Body, DateTime CreatedAtUtc, DateTime? EditedAtUtc);

public sealed record CreateTaskLabelRequest(string Name, string Color);
public sealed record TaskLabelResponse(Guid Id, string Name, string Color);

public sealed record CreateTaskAttachmentRequest(string FileName, string ContentType, long SizeBytes, string StoragePath);
public sealed record TaskAttachmentResponse(Guid Id, string FileName, string ContentType, long SizeBytes, string StoragePath, string UploadedByUserId, DateTime UploadedAtUtc);
