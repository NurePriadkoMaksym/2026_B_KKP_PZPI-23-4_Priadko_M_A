using Tasky.Application.Common;

namespace Tasky.Application.Tasks;

public interface ITaskService
{
    Task<Result<TaskResponse>> CreateAsync(string userId, Guid projectId, CreateTaskRequest request);
    Task<Result<IReadOnlyList<TaskResponse>>> SearchAsync(string userId, Guid projectId, TaskSearchRequest request);
    Task<Result<TaskResponse>> GetByIdAsync(string userId, Guid projectId, Guid taskId);
    Task<Result> UpdateAsync(string userId, Guid projectId, Guid taskId, UpdateTaskRequest request);
    Task<Result> DeleteAsync(string userId, Guid projectId, Guid taskId);
    Task<Result<TaskCommentResponse>> AddCommentAsync(string userId, Guid projectId, Guid taskId, CreateTaskCommentRequest request);
    Task<Result<IReadOnlyList<TaskCommentResponse>>> GetCommentsAsync(string userId, Guid projectId, Guid taskId);
    Task<Result<TaskLabelResponse>> CreateLabelAsync(string userId, Guid teamId, CreateTaskLabelRequest request);
    Task<Result<IReadOnlyList<TaskLabelResponse>>> GetLabelsAsync(string userId, Guid teamId);
    Task<Result<TaskAttachmentResponse>> AddAttachmentAsync(string userId, Guid projectId, Guid taskId, CreateTaskAttachmentRequest request);
}
