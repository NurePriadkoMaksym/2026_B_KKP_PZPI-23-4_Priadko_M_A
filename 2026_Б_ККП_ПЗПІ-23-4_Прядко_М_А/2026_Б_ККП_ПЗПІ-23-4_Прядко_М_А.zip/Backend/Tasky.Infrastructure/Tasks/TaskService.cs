using Microsoft.EntityFrameworkCore;
using Tasky.Application.Authorization;
using Tasky.Application.Common;
using Tasky.Application.Tasks;
using Tasky.Domain;
using Tasky.Domain.Tasks;
using Tasky.Infrastructure.Data;

namespace Tasky.Infrastructure.Tasks;

internal sealed class TaskService : ITaskService
{
    private readonly ApplicationDbContext _dbContext;
    private readonly ITaskyAuthorizationService _authorizationService;

    public TaskService(ApplicationDbContext dbContext, ITaskyAuthorizationService authorizationService)
    {
        _dbContext = dbContext;
        _authorizationService = authorizationService;
    }

    public async Task<Result<TaskResponse>> CreateAsync(string userId, Guid projectId, CreateTaskRequest request)
    {
        var project = await _dbContext.Projects.AsNoTracking().SingleOrDefaultAsync(x => x.Id == projectId);
        if (project is null || !await _authorizationService.IsTeamMemberAsync(project.TeamId, userId))
        {
            return Result<TaskResponse>.Fail("not_found", "Project was not found.", 404);
        }

        var column = await _dbContext.KanbanColumns.AsNoTracking().SingleOrDefaultAsync(x => x.Id == request.ColumnId && x.ProjectId == projectId);
        if (column is null)
        {
            return Result<TaskResponse>.Fail("invalid_column", "Column does not belong to the project.", 400);
        }

        if (!await AllUsersAreTeamMembers(project.TeamId, request.AssigneeUserIds))
        {
            return Result<TaskResponse>.Fail("invalid_assignee", "Every assignee must be a team member.", 400);
        }

        if (!await AllLabelsBelongToTeam(project.TeamId, request.LabelIds))
        {
            return Result<TaskResponse>.Fail("invalid_label", "Every label must belong to the team.", 400);
        }

        var task = new TaskItem
        {
            Id = Guid.NewGuid(),
            ProjectId = projectId,
            ColumnId = request.ColumnId,
            Title = request.Title.Trim(),
            Description = request.Description?.Trim(),
            Priority = request.Priority,
            Status = column.MappedStatus,
            DeadlineUtc = request.DeadlineUtc,
            CreatedByUserId = userId,
            Assignments = request.AssigneeUserIds.Distinct().Select(x => new TaskAssignment { UserId = x, AssignedByUserId = userId }).ToList(),
            LabelAssignments = request.LabelIds.Distinct().Select(x => new TaskLabelAssignment { TaskLabelId = x }).ToList()
        };

        _dbContext.TaskItems.Add(task);
        await _dbContext.SaveChangesAsync();
        return Result<TaskResponse>.Created(await LoadTaskResponse(task.Id));
    }

    public async Task<Result<IReadOnlyList<TaskResponse>>> SearchAsync(string userId, Guid projectId, TaskSearchRequest request)
    {
        var project = await _dbContext.Projects.AsNoTracking().SingleOrDefaultAsync(x => x.Id == projectId);
        if (project is null || !await _authorizationService.IsTeamMemberAsync(project.TeamId, userId))
        {
            return Result<IReadOnlyList<TaskResponse>>.Fail("not_found", "Project was not found.", 404);
        }

        var query = _dbContext.TaskItems.AsNoTracking()
            .Where(x => x.ProjectId == projectId)
            .Include(x => x.Assignments)
            .Include(x => x.LabelAssignments).ThenInclude(x => x.TaskLabel)
            .Include(x => x.Comments)
            .Include(x => x.Attachments)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(request.Query))
        {
            query = query.Where(x => x.Title.Contains(request.Query) || (x.Description != null && x.Description.Contains(request.Query)));
        }

        if (request.AssigneeUserId is not null)
        {
            query = query.Where(x => x.Assignments.Any(a => a.UserId == request.AssigneeUserId));
        }

        if (request.Priority is not null)
        {
            query = query.Where(x => x.Priority == request.Priority);
        }

        if (request.Status is not null)
        {
            query = query.Where(x => x.Status == request.Status);
        }

        if (request.LabelId is not null)
        {
            query = query.Where(x => x.LabelAssignments.Any(l => l.TaskLabelId == request.LabelId));
        }

        if (request.DeadlineFromUtc is not null)
        {
            query = query.Where(x => x.DeadlineUtc >= request.DeadlineFromUtc);
        }

        if (request.DeadlineToUtc is not null)
        {
            query = query.Where(x => x.DeadlineUtc <= request.DeadlineToUtc);
        }

        var tasks = await query
            .OrderBy(x => x.Status)
            .ThenByDescending(x => x.Priority)
            .ThenBy(x => x.DeadlineUtc)
            .Skip((request.Page - 1) * request.PageSize)
            .Take(request.PageSize)
            .Select(x => ToResponse(x))
            .ToListAsync();

        return Result<IReadOnlyList<TaskResponse>>.Ok(tasks);
    }

    public async Task<Result<TaskResponse>> GetByIdAsync(string userId, Guid projectId, Guid taskId)
    {
        var project = await _dbContext.Projects.AsNoTracking().SingleOrDefaultAsync(x => x.Id == projectId);
        if (project is null || !await _authorizationService.IsTeamMemberAsync(project.TeamId, userId))
        {
            return Result<TaskResponse>.Fail("not_found", "Task was not found.", 404);
        }

        var task = await QueryTask().SingleOrDefaultAsync(x => x.ProjectId == projectId && x.Id == taskId);
        return task is null ? Result<TaskResponse>.Fail("not_found", "Task was not found.", 404) : Result<TaskResponse>.Ok(ToResponse(task));
    }

    public async Task<Result> UpdateAsync(string userId, Guid projectId, Guid taskId, UpdateTaskRequest request)
    {
        var project = await _dbContext.Projects.AsNoTracking().SingleOrDefaultAsync(x => x.Id == projectId);
        if (project is null || !await _authorizationService.IsTeamMemberAsync(project.TeamId, userId))
        {
            return Result.Fail("not_found", "Task was not found.", 404);
        }

        var task = await _dbContext.TaskItems.Include(x => x.Assignments).Include(x => x.LabelAssignments).SingleOrDefaultAsync(x => x.ProjectId == projectId && x.Id == taskId);
        if (task is null)
        {
            return Result.Fail("not_found", "Task was not found.", 404);
        }

        if (request.ColumnId is not null)
        {
            var column = await _dbContext.KanbanColumns.AsNoTracking().SingleOrDefaultAsync(x => x.ProjectId == projectId && x.Id == request.ColumnId);
            if (column is null)
            {
                return Result.Fail("invalid_column", "Column does not belong to the project.", 400);
            }

            task.ColumnId = column.Id;
            task.Status = column.MappedStatus;
        }

        if (request.AssigneeUserIds is not null)
        {
            if (!await AllUsersAreTeamMembers(project.TeamId, request.AssigneeUserIds))
            {
                return Result.Fail("invalid_assignee", "Every assignee must be a team member.", 400);
            }

            _dbContext.TaskAssignments.RemoveRange(task.Assignments);
            task.Assignments = request.AssigneeUserIds.Distinct().Select(x => new TaskAssignment { TaskItemId = task.Id, UserId = x, AssignedByUserId = userId }).ToList();
        }

        if (request.LabelIds is not null)
        {
            if (!await AllLabelsBelongToTeam(project.TeamId, request.LabelIds))
            {
                return Result.Fail("invalid_label", "Every label must belong to the team.", 400);
            }

            _dbContext.TaskLabelAssignments.RemoveRange(task.LabelAssignments);
            task.LabelAssignments = request.LabelIds.Distinct().Select(x => new TaskLabelAssignment { TaskItemId = task.Id, TaskLabelId = x }).ToList();
        }

        task.Title = request.Title?.Trim() ?? task.Title;
        task.Description = request.Description?.Trim() ?? task.Description;
        task.Priority = request.Priority ?? task.Priority;
        task.Status = request.Status ?? task.Status;
        task.DeadlineUtc = request.DeadlineUtc ?? task.DeadlineUtc;
        task.UpdatedAtUtc = DateTime.UtcNow;
        task.UpdatedByUserId = userId;

        await _dbContext.SaveChangesAsync();
        return Result.Ok();
    }

    public async Task<Result> DeleteAsync(string userId, Guid projectId, Guid taskId)
    {
        var task = await _dbContext.TaskItems.Include(x => x.Project).SingleOrDefaultAsync(x => x.ProjectId == projectId && x.Id == taskId);
        if (task is null)
        {
            return Result.Fail("not_found", "Task was not found.", 404);
        }

        if (!await _authorizationService.IsTeamManagerAsync(task.Project!.TeamId, userId))
        {
            return Result.Fail("forbidden", "Only team managers can delete tasks.", 403);
        }

        await _dbContext.SoftDeleteAsync(task, userId);
        return Result.Ok();
    }

    public async Task<Result<TaskCommentResponse>> AddCommentAsync(string userId, Guid projectId, Guid taskId, CreateTaskCommentRequest request)
    {
        var task = await _dbContext.TaskItems.Include(x => x.Project).SingleOrDefaultAsync(x => x.ProjectId == projectId && x.Id == taskId);
        if (task is null || !await _authorizationService.IsTeamMemberAsync(task.Project!.TeamId, userId))
        {
            return Result<TaskCommentResponse>.Fail("not_found", "Task was not found.", 404);
        }

        var comment = new TaskComment { Id = Guid.NewGuid(), TaskItemId = taskId, AuthorUserId = userId, Body = request.Body.Trim() };
        _dbContext.TaskComments.Add(comment);
        await _dbContext.SaveChangesAsync();
        return Result<TaskCommentResponse>.Created(ToResponse(comment));
    }

    public async Task<Result<IReadOnlyList<TaskCommentResponse>>> GetCommentsAsync(string userId, Guid projectId, Guid taskId)
    {
        var task = await _dbContext.TaskItems.Include(x => x.Project).SingleOrDefaultAsync(x => x.ProjectId == projectId && x.Id == taskId);
        if (task is null || !await _authorizationService.IsTeamMemberAsync(task.Project!.TeamId, userId))
        {
            return Result<IReadOnlyList<TaskCommentResponse>>.Fail("not_found", "Task was not found.", 404);
        }

        var comments = await _dbContext.TaskComments.AsNoTracking().Where(x => x.TaskItemId == taskId).OrderBy(x => x.CreatedAtUtc).Select(x => ToResponse(x)).ToListAsync();
        return Result<IReadOnlyList<TaskCommentResponse>>.Ok(comments);
    }

    public async Task<Result<TaskLabelResponse>> CreateLabelAsync(string userId, Guid teamId, CreateTaskLabelRequest request)
    {
        if (!await _authorizationService.IsTeamMemberAsync(teamId, userId))
        {
            return Result<TaskLabelResponse>.Fail("not_found", "Team was not found.", 404);
        }

        var label = new TaskLabel { Id = Guid.NewGuid(), TeamId = teamId, Name = request.Name.Trim(), Color = request.Color.Trim(), CreatedByUserId = userId };
        _dbContext.TaskLabels.Add(label);
        await _dbContext.SaveChangesAsync();
        return Result<TaskLabelResponse>.Created(ToResponse(label));
    }

    public async Task<Result<IReadOnlyList<TaskLabelResponse>>> GetLabelsAsync(string userId, Guid teamId)
    {
        if (!await _authorizationService.IsTeamMemberAsync(teamId, userId))
        {
            return Result<IReadOnlyList<TaskLabelResponse>>.Fail("not_found", "Team was not found.", 404);
        }

        var labels = await _dbContext.TaskLabels.AsNoTracking().Where(x => x.TeamId == teamId).OrderBy(x => x.Name).Select(x => ToResponse(x)).ToListAsync();
        return Result<IReadOnlyList<TaskLabelResponse>>.Ok(labels);
    }

    public async Task<Result<TaskAttachmentResponse>> AddAttachmentAsync(string userId, Guid projectId, Guid taskId, CreateTaskAttachmentRequest request)
    {
        var task = await _dbContext.TaskItems.Include(x => x.Project).SingleOrDefaultAsync(x => x.ProjectId == projectId && x.Id == taskId);
        if (task is null || !await _authorizationService.IsTeamMemberAsync(task.Project!.TeamId, userId))
        {
            return Result<TaskAttachmentResponse>.Fail("not_found", "Task was not found.", 404);
        }

        var attachment = new TaskAttachment
        {
            Id = Guid.NewGuid(),
            TaskItemId = taskId,
            FileName = request.FileName.Trim(),
            ContentType = request.ContentType.Trim(),
            SizeBytes = request.SizeBytes,
            StoragePath = request.StoragePath.Trim(),
            UploadedByUserId = userId
        };
        _dbContext.TaskAttachments.Add(attachment);
        await _dbContext.SaveChangesAsync();
        return Result<TaskAttachmentResponse>.Created(ToResponse(attachment));
    }

    private IQueryable<TaskItem> QueryTask()
    {
        return _dbContext.TaskItems.AsNoTracking()
            .Include(x => x.Assignments)
            .Include(x => x.LabelAssignments).ThenInclude(x => x.TaskLabel)
            .Include(x => x.Comments)
            .Include(x => x.Attachments);
    }

    private async Task<TaskResponse> LoadTaskResponse(Guid taskId)
    {
        return ToResponse(await QueryTask().SingleAsync(x => x.Id == taskId));
    }

    private async Task<bool> AllUsersAreTeamMembers(Guid teamId, IReadOnlyList<string> userIds)
    {
        var distinctIds = userIds.Distinct().ToList();
        var count = await _dbContext.TeamMembers.CountAsync(x => x.TeamId == teamId && distinctIds.Contains(x.UserId));
        return count == distinctIds.Count;
    }

    private async Task<bool> AllLabelsBelongToTeam(Guid teamId, IReadOnlyList<Guid> labelIds)
    {
        var distinctIds = labelIds.Distinct().ToList();
        var count = await _dbContext.TaskLabels.CountAsync(x => x.TeamId == teamId && distinctIds.Contains(x.Id));
        return count == distinctIds.Count;
    }

    private static TaskResponse ToResponse(TaskItem task)
    {
        return new TaskResponse(
            task.Id,
            task.ProjectId,
            task.ColumnId,
            task.Title,
            task.Description,
            task.Priority,
            task.Status,
            task.DeadlineUtc,
            task.Assignments.Select(x => x.UserId).ToList(),
            task.LabelAssignments.Where(x => x.TaskLabel is not null).Select(x => ToResponse(x.TaskLabel!)).ToList(),
            task.Comments.Count,
            task.Attachments.Count,
            task.CreatedAtUtc,
            task.UpdatedAtUtc);
    }

    private static TaskCommentResponse ToResponse(TaskComment comment) => new(comment.Id, comment.TaskItemId, comment.AuthorUserId, comment.Body, comment.CreatedAtUtc, comment.EditedAtUtc);
    private static TaskLabelResponse ToResponse(TaskLabel label) => new(label.Id, label.Name, label.Color);
    private static TaskAttachmentResponse ToResponse(TaskAttachment attachment) => new(attachment.Id, attachment.FileName, attachment.ContentType, attachment.SizeBytes, attachment.StoragePath, attachment.UploadedByUserId, attachment.UploadedAtUtc);
}
