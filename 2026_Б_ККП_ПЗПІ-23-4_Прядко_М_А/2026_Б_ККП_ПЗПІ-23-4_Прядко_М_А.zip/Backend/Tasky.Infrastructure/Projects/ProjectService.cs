using Microsoft.EntityFrameworkCore;
using Tasky.Application.Authorization;
using Tasky.Application.Common;
using Tasky.Application.Projects;
using Tasky.Domain;
using Tasky.Domain.Projects;
using Tasky.Infrastructure.Data;

namespace Tasky.Infrastructure.Projects;

internal sealed class ProjectService : IProjectService
{
    private readonly ApplicationDbContext _dbContext;
    private readonly ITaskyAuthorizationService _authorizationService;

    public ProjectService(ApplicationDbContext dbContext, ITaskyAuthorizationService authorizationService)
    {
        _dbContext = dbContext;
        _authorizationService = authorizationService;
    }

    public async Task<Result<ProjectResponse>> CreateAsync(string userId, Guid teamId, CreateProjectRequest request)
    {
        if (!await _authorizationService.IsTeamMemberAsync(teamId, userId))
        {
            return Result<ProjectResponse>.Fail("not_found", "Team was not found.", 404);
        }

        var project = new Project
        {
            Id = Guid.NewGuid(),
            TeamId = teamId,
            Name = request.Name.Trim(),
            Description = request.Description?.Trim(),
            CreatedByUserId = userId,
            Columns =
            [
                new KanbanColumn { Id = Guid.NewGuid(), Name = "Backlog", Position = 0, MappedStatus = WorkItemStatus.Todo },
                new KanbanColumn { Id = Guid.NewGuid(), Name = "In Progress", Position = 1, MappedStatus = WorkItemStatus.InProgress },
                new KanbanColumn { Id = Guid.NewGuid(), Name = "Done", Position = 2, MappedStatus = WorkItemStatus.Done }
            ]
        };

        _dbContext.Projects.Add(project);
        await _dbContext.SaveChangesAsync();
        return Result<ProjectResponse>.Created(ToResponse(project));
    }

    public async Task<Result<IReadOnlyList<ProjectResponse>>> GetTeamProjectsAsync(string userId, Guid teamId)
    {
        if (!await _authorizationService.IsTeamMemberAsync(teamId, userId))
        {
            return Result<IReadOnlyList<ProjectResponse>>.Fail("not_found", "Team was not found.", 404);
        }

        var projects = await _dbContext.Projects.AsNoTracking()
            .Include(x => x.Columns.OrderBy(c => c.Position))
            .Where(x => x.TeamId == teamId)
            .Select(x => ToResponse(x))
            .ToListAsync();
        return Result<IReadOnlyList<ProjectResponse>>.Ok(projects);
    }

    public async Task<Result<KanbanColumnResponse>> AddColumnAsync(string userId, Guid projectId, CreateKanbanColumnRequest request)
    {
        var project = await _dbContext.Projects.SingleOrDefaultAsync(x => x.Id == projectId);
        if (project is null)
        {
            return Result<KanbanColumnResponse>.Fail("not_found", "Project was not found.", 404);
        }

        if (!await _authorizationService.IsTeamManagerAsync(project.TeamId, userId))
        {
            return Result<KanbanColumnResponse>.Fail("forbidden", "Only team managers can change board columns.", 403);
        }

        var column = new KanbanColumn
        {
            Id = Guid.NewGuid(),
            ProjectId = projectId,
            Name = request.Name.Trim(),
            Position = request.Position,
            MappedStatus = request.MappedStatus
        };

        _dbContext.KanbanColumns.Add(column);
        await _dbContext.SaveChangesAsync();
        return Result<KanbanColumnResponse>.Created(ToResponse(column));
    }

    public async Task<Result> DeleteAsync(string userId, Guid projectId)
    {
        var project = await _dbContext.Projects.SingleOrDefaultAsync(x => x.Id == projectId);
        if (project is null)
        {
            return Result.Fail("not_found", "Project was not found.", 404);
        }

        if (!await _authorizationService.IsTeamManagerAsync(project.TeamId, userId))
        {
            return Result.Fail("forbidden", "Only team managers can delete projects.", 403);
        }

        await _dbContext.SoftDeleteAsync(project, userId);
        return Result.Ok();
    }

    private static ProjectResponse ToResponse(Project project)
    {
        return new ProjectResponse(project.Id, project.TeamId, project.Name, project.Description, project.Columns.OrderBy(x => x.Position).Select(ToResponse).ToList());
    }

    private static KanbanColumnResponse ToResponse(KanbanColumn column)
    {
        return new KanbanColumnResponse(column.Id, column.Name, column.Position, column.MappedStatus);
    }
}
