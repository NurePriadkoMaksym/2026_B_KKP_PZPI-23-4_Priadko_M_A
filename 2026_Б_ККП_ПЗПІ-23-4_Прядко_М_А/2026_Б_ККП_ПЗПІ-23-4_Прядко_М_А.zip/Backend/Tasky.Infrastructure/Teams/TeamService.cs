using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Tasky.Application.Authorization;
using Tasky.Application.Common;
using Tasky.Application.Teams;
using Tasky.Domain;
using Tasky.Domain.Projects;
using Tasky.Domain.Teams;
using Tasky.Infrastructure.Data;
using Tasky.Infrastructure.Emails;
using Tasky.Infrastructure.Identity;
using Tasky.Infrastructure.Security;

namespace Tasky.Infrastructure.Teams;

internal sealed class TeamService : ITeamService
{
    private readonly ApplicationDbContext _dbContext;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly ITaskyAuthorizationService _authorizationService;
    private readonly InvitationOptions _invitationOptions;

    public TeamService(
        ApplicationDbContext dbContext,
        UserManager<ApplicationUser> userManager,
        ITaskyAuthorizationService authorizationService,
        IOptions<InvitationOptions> invitationOptions)
    {
        _dbContext = dbContext;
        _userManager = userManager;
        _authorizationService = authorizationService;
        _invitationOptions = invitationOptions.Value;
    }

    public async Task<Result<TeamResponse>> CreateAsync(string userId, CreateTeamRequest request)
    {
        var team = new Team
        {
            Id = Guid.NewGuid(),
            Name = request.Name.Trim(),
            Description = request.Description?.Trim(),
            CreatedByUserId = userId,
            Members = [new TeamMember { UserId = userId, Role = TeamRole.Owner }]
        };

        var project = new Project
        {
            Id = Guid.NewGuid(),
            TeamId = team.Id,
            Name = "Default",
            CreatedByUserId = userId,
            Columns =
            [
                new KanbanColumn { Id = Guid.NewGuid(), Name = "Backlog", Position = 0, MappedStatus = WorkItemStatus.Todo },
                new KanbanColumn { Id = Guid.NewGuid(), Name = "In Progress", Position = 1, MappedStatus = WorkItemStatus.InProgress },
                new KanbanColumn { Id = Guid.NewGuid(), Name = "Review", Position = 2, MappedStatus = WorkItemStatus.InProgress },
                new KanbanColumn { Id = Guid.NewGuid(), Name = "Done", Position = 3, MappedStatus = WorkItemStatus.Done }
            ]
        };

        team.Projects.Add(project);
        _dbContext.Teams.Add(team);
        await _dbContext.SaveChangesAsync();
        return Result<TeamResponse>.Created(new TeamResponse(team.Id, team.Name, team.Description, TeamRole.Owner, 1));
    }

    public async Task<Result<IReadOnlyList<TeamResponse>>> GetMineAsync(string userId)
    {
        var teams = await _dbContext.TeamMembers.AsNoTracking()
            .Where(x => x.UserId == userId)
            .Select(x => new TeamResponse(x.TeamId, x.Team!.Name, x.Team.Description, x.Role, x.Team.Members.Count))
            .ToListAsync();
        return Result<IReadOnlyList<TeamResponse>>.Ok(teams);
    }

    public async Task<Result<TeamResponse>> GetByIdAsync(string userId, Guid teamId)
    {
        var team = await _dbContext.TeamMembers.AsNoTracking()
            .Where(x => x.UserId == userId && x.TeamId == teamId)
            .Select(x => new TeamResponse(x.TeamId, x.Team!.Name, x.Team.Description, x.Role, x.Team.Members.Count))
            .SingleOrDefaultAsync();
        return team is null ? Result<TeamResponse>.Fail("not_found", "Team was not found.", 404) : Result<TeamResponse>.Ok(team);
    }

    public async Task<Result<IReadOnlyList<TeamMemberResponse>>> GetMembersAsync(string userId, Guid teamId)
    {
        if (!await _authorizationService.IsTeamMemberAsync(teamId, userId))
        {
            return Result<IReadOnlyList<TeamMemberResponse>>.Fail("not_found", "Team was not found.", 404);
        }

        var users = _dbContext.Users.AsNoTracking();
        var members = await _dbContext.TeamMembers.AsNoTracking()
            .Where(x => x.TeamId == teamId)
            .Join(users, member => member.UserId, user => user.Id, (member, user) =>
                new TeamMemberResponse(member.UserId, user.UserName ?? string.Empty, user.Email ?? string.Empty, member.Role, member.JoinedAtUtc))
            .ToListAsync();
        return Result<IReadOnlyList<TeamMemberResponse>>.Ok(members);
    }

    public async Task<Result<InvitationResponse>> InviteAsync(string userId, Guid teamId, InviteUserRequest request)
    {
        if (!await _authorizationService.IsTeamOwnerAsync(teamId, userId))
        {
            return Result<InvitationResponse>.Fail("forbidden", "Only team owners can invite users.", 403);
        }

        var userName = string.IsNullOrWhiteSpace(request.UserName) ? null : request.UserName.Trim();
        var email = string.IsNullOrWhiteSpace(request.Email) ? null : request.Email.Trim();
        var invitedUser = userName is not null
            ? await _userManager.FindByNameAsync(userName)
            : email is not null
                ? await _userManager.FindByEmailAsync(email)
                : null;
        var team = await _dbContext.Teams.AsNoTracking().SingleOrDefaultAsync(x => x.Id == teamId);
        if (team is null)
        {
            return Result<InvitationResponse>.Fail("not_found", "Team was not found.", 404);
        }

        if (userName is not null && invitedUser is null)
        {
            return Result<InvitationResponse>.Fail("user_not_found", "User with this username was not found.", 404);
        }

        if (invitedUser is not null && await _authorizationService.IsTeamMemberAsync(teamId, invitedUser.Id))
        {
            return Result<InvitationResponse>.Fail("already_member", "User is already a team member.", 409);
        }

        var rawToken = TokenHasher.CreateRawToken();
        var invitation = new TeamInvitation
        {
            Id = Guid.NewGuid(),
            TeamId = teamId,
            InvitedUserName = userName,
            InvitedEmail = email,
            InvitedUserId = invitedUser?.Id,
            InvitedByUserId = userId,
            TokenHash = TokenHasher.Hash(rawToken),
            ExpiresAtUtc = DateTime.UtcNow.AddDays(7)
        };

        _dbContext.TeamInvitations.Add(invitation);
        await _dbContext.SaveChangesAsync();

        var invitationLink = BuildInvitationLink(rawToken);

        return Result<InvitationResponse>.Created(ToInvitationResponse(invitation, rawToken, invitationLink));
    }

    public async Task<Result<IReadOnlyList<PendingInvitationResponse>>> GetMyPendingInvitationsAsync(string userId)
    {
        var user = await _userManager.FindByIdAsync(userId);
        if (user is null)
        {
            return Result<IReadOnlyList<PendingInvitationResponse>>.Fail("unauthorized", "User is not authenticated.", 401);
        }

        var now = DateTime.UtcNow;
        var invitations = await _dbContext.TeamInvitations
            .AsNoTracking()
            .Where(x =>
                x.Status == InvitationStatus.Pending &&
                x.ExpiresAtUtc > now &&
                (x.InvitedUserId == userId ||
                 x.InvitedUserName == user.UserName ||
                 x.InvitedEmail == user.Email))
            .OrderByDescending(x => x.CreatedAtUtc)
            .Select(x => new
            {
                x.Id,
                x.TeamId,
                TeamName = x.Team!.Name,
                x.InvitedByUserId,
                x.CreatedAtUtc,
                x.ExpiresAtUtc
            })
            .ToListAsync();

        var responses = invitations
            .Select(x => new PendingInvitationResponse(
                x.Id,
                x.TeamId,
                x.TeamName,
                x.InvitedByUserId,
                x.CreatedAtUtc,
                x.ExpiresAtUtc))
            .ToList();

        return Result<IReadOnlyList<PendingInvitationResponse>>.Ok(responses);
    }

    public async Task<Result> AcceptInvitationAsync(string userId, AcceptInvitationRequest request)
    {
        var hash = TokenHasher.Hash(request.Token);
        var invitation = await _dbContext.TeamInvitations.SingleOrDefaultAsync(x => x.TokenHash == hash && x.Status == InvitationStatus.Pending);
        return await AcceptInvitationCoreAsync(userId, invitation, allowUniversal: true);
    }

    public async Task<Result> AcceptInvitationAsync(string userId, Guid invitationId)
    {
        var invitation = await _dbContext.TeamInvitations.SingleOrDefaultAsync(x => x.Id == invitationId && x.Status == InvitationStatus.Pending);
        return await AcceptInvitationCoreAsync(userId, invitation, allowUniversal: false);
    }

    private async Task<Result> AcceptInvitationCoreAsync(string userId, TeamInvitation? invitation, bool allowUniversal)
    {
        var user = await _userManager.FindByIdAsync(userId);
        if (user is null)
        {
            return Result.Fail("unauthorized", "User is not authenticated.", 401);
        }

        if (invitation is null || invitation.ExpiresAtUtc < DateTime.UtcNow)
        {
            return Result.Fail("not_found", "Invitation was not found or expired.", 404);
        }

        var isUniversal = invitation.InvitedUserId is null
            && invitation.InvitedEmail is null
            && invitation.InvitedUserName is null;
        var matches = (allowUniversal && isUniversal)
            || invitation.InvitedUserId == userId
            || string.Equals(invitation.InvitedEmail, user.Email, StringComparison.OrdinalIgnoreCase)
            || string.Equals(invitation.InvitedUserName, user.UserName, StringComparison.OrdinalIgnoreCase);
        if (!matches)
        {
            return Result.Fail("forbidden", "Invitation belongs to another user.", 403);
        }

        if (!await _authorizationService.IsTeamMemberAsync(invitation.TeamId, userId))
        {
            _dbContext.TeamMembers.Add(new TeamMember { TeamId = invitation.TeamId, UserId = userId, Role = TeamRole.Member });
        }

        invitation.Status = InvitationStatus.Accepted;
        invitation.RespondedAtUtc = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync();
        return Result.Ok();
    }

    public async Task<Result> ChangeMemberRoleAsync(string userId, Guid teamId, string memberUserId, ChangeMemberRoleRequest request)
    {
        if (!await _authorizationService.IsTeamManagerAsync(teamId, userId))
        {
            return Result.Fail("forbidden", "Only team managers can change roles.", 403);
        }

        var member = await _dbContext.TeamMembers.SingleOrDefaultAsync(x => x.TeamId == teamId && x.UserId == memberUserId);
        if (member is null)
        {
            return Result.Fail("not_found", "Team member was not found.", 404);
        }

        var actorRole = await _authorizationService.GetTeamRoleAsync(teamId, userId);
        if (member.Role == TeamRole.Owner && actorRole != TeamRole.Owner)
        {
            return Result.Fail("forbidden", "Only team owners can change another owner's role.", 403);
        }

        if (member.Role == TeamRole.Owner && request.Role != TeamRole.Owner && await IsLastOwnerAsync(teamId, memberUserId))
        {
            return Result.Fail("last_owner", "A team must always have at least one owner.", 409);
        }

        member.Role = request.Role;
        await _dbContext.SaveChangesAsync();
        return Result.Ok();
    }

    public async Task<Result> RemoveMemberAsync(string userId, Guid teamId, string memberUserId)
    {
        if (!await _authorizationService.IsTeamOwnerAsync(teamId, userId))
        {
            return Result.Fail("forbidden", "Only team owners can remove users.", 403);
        }

        var member = await _dbContext.TeamMembers.SingleOrDefaultAsync(x => x.TeamId == teamId && x.UserId == memberUserId);
        if (member is null)
        {
            return Result.Fail("not_found", "Team member was not found.", 404);
        }

        var actorRole = await _authorizationService.GetTeamRoleAsync(teamId, userId);
        if (member.Role == TeamRole.Owner && actorRole != TeamRole.Owner)
        {
            return Result.Fail("forbidden", "Only team owners can remove another owner.", 403);
        }

        if (member.Role == TeamRole.Owner && await IsLastOwnerAsync(teamId, memberUserId))
        {
            return Result.Fail("last_owner", "A team must always have at least one owner.", 409);
        }

        _dbContext.TeamMembers.Remove(member);
        await _dbContext.SaveChangesAsync();
        return Result.Ok();
    }

    public async Task<Result> DeleteAsync(string userId, Guid teamId)
    {
        var team = await _dbContext.Teams.SingleOrDefaultAsync(x => x.Id == teamId);
        if (team is null)
        {
            return Result.Fail("not_found", "Team was not found.", 404);
        }

        if (!await _authorizationService.IsTeamOwnerAsync(teamId, userId))
        {
            return Result.Fail("forbidden", "Only team owner can delete a team.", 403);
        }

        await _dbContext.SoftDeleteAsync(team, userId);
        return Result.Ok();
    }

    private async Task<bool> IsLastOwnerAsync(Guid teamId, string ownerUserId)
    {
        var ownersCount = await _dbContext.TeamMembers.CountAsync(x => x.TeamId == teamId && x.Role == TeamRole.Owner);
        return ownersCount == 1 && await _authorizationService.IsTeamOwnerAsync(teamId, ownerUserId);
    }

    private string BuildInvitationLink(string rawToken)
    {
        var baseUrl = _invitationOptions.FrontendBaseUrl.TrimEnd('/');
        var path = _invitationOptions.AcceptInvitationPath.StartsWith('/')
            ? _invitationOptions.AcceptInvitationPath
            : "/" + _invitationOptions.AcceptInvitationPath;

        return $"{baseUrl}{path}?token={Uri.EscapeDataString(rawToken)}";
    }

    private static InvitationResponse ToInvitationResponse(
        TeamInvitation invitation,
        string rawToken,
        string invitationLink)
    {
        return new InvitationResponse(
            invitation.Id,
            invitation.TeamId,
            invitation.InvitedUserName,
            invitation.InvitedEmail,
            invitation.Status,
            invitation.ExpiresAtUtc,
            rawToken,
            invitationLink,
            invitation.InvitedUserId is not null || invitation.InvitedEmail is not null || invitation.InvitedUserName is not null);
    }
}
