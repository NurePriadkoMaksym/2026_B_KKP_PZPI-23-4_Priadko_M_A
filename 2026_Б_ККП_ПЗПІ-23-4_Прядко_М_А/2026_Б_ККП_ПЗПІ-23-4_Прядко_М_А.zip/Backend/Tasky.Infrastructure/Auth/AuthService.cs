using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using Tasky.Application.Auth;
using Tasky.Application.Common;
using Tasky.Domain.Auth;
using Tasky.Infrastructure.Data;
using Tasky.Infrastructure.Identity;
using Tasky.Infrastructure.Security;

namespace Tasky.Infrastructure.Auth;

internal sealed class AuthService : IAuthService
{
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly SignInManager<ApplicationUser> _signInManager;
    private readonly ApplicationDbContext _dbContext;
    private readonly JwtTokenService _jwtTokenService;
    private readonly JwtOptions _jwtOptions;

    public AuthService(
        UserManager<ApplicationUser> userManager,
        SignInManager<ApplicationUser> signInManager,
        ApplicationDbContext dbContext,
        JwtTokenService jwtTokenService,
        IOptions<JwtOptions> jwtOptions)
    {
        _userManager = userManager;
        _signInManager = signInManager;
        _dbContext = dbContext;
        _jwtTokenService = jwtTokenService;
        _jwtOptions = jwtOptions.Value;
    }

    public async Task<Result<AuthResponse>> RegisterAsync(RegisterRequest request)
    {
        var user = new ApplicationUser { UserName = request.UserName.Trim(), Email = request.Email.Trim() };
        var result = await _userManager.CreateAsync(user, request.Password);
        return result.Succeeded
            ? Result<AuthResponse>.Created(await CreateAuthResponseAsync(user))
            : Result<AuthResponse>.Fail("identity_error", string.Join(" ", result.Errors.Select(x => x.Description)), 400);
    }

    public async Task<Result<AuthResponse>> LoginAsync(LoginRequest request)
    {
        var lookup = request.UserNameOrEmail.Trim();
        var user = await _userManager.FindByNameAsync(lookup) ?? await _userManager.FindByEmailAsync(lookup);
        if (user is null)
        {
            return Result<AuthResponse>.Fail("invalid_credentials", "Invalid username/email or password.", 401);
        }

        var result = await _signInManager.CheckPasswordSignInAsync(user, request.Password, lockoutOnFailure: false);
        return result.Succeeded
            ? Result<AuthResponse>.Ok(await CreateAuthResponseAsync(user))
            : Result<AuthResponse>.Fail("invalid_credentials", "Invalid username/email or password.", 401);
    }

    public async Task<Result<AuthResponse>> RefreshAsync(RefreshTokenRequest request)
    {
        var oldHash = TokenHasher.Hash(request.RefreshToken);
        var token = await _dbContext.RefreshTokens.SingleOrDefaultAsync(x => x.TokenHash == oldHash);
        if (token is null || !token.IsActive)
        {
            return Result<AuthResponse>.Fail("invalid_refresh_token", "Refresh token is invalid or expired.", 401);
        }

        var user = await _userManager.FindByIdAsync(token.UserId);
        if (user is null)
        {
            return Result<AuthResponse>.Fail("user_not_found", "User was not found.", 404);
        }

        var rawRefreshToken = TokenHasher.CreateRawToken();
        var newHash = TokenHasher.Hash(rawRefreshToken);
        token.RevokedAtUtc = DateTime.UtcNow;
        token.ReplacedByTokenHash = newHash;
        _dbContext.RefreshTokens.Add(new RefreshToken
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            TokenHash = newHash,
            ExpiresAtUtc = DateTime.UtcNow.AddDays(_jwtOptions.RefreshTokenExpiresDays)
        });
        await _dbContext.SaveChangesAsync();

        return Result<AuthResponse>.Ok(new AuthResponse(_jwtTokenService.CreateAccessToken(user), rawRefreshToken, ToUserResponse(user)));
    }

    public async Task<Result> RevokeRefreshTokenAsync(string userId, RevokeRefreshTokenRequest request)
    {
        var hash = TokenHasher.Hash(request.RefreshToken);
        var token = await _dbContext.RefreshTokens.SingleOrDefaultAsync(x => x.TokenHash == hash);
        if (token is null || token.UserId != userId)
        {
            return Result.Fail("not_found", "Refresh token was not found.", 404);
        }

        if (token.RevokedAtUtc is null)
        {
            token.RevokedAtUtc = DateTime.UtcNow;
            await _dbContext.SaveChangesAsync();
        }

        return Result.Ok();
    }

    public async Task<Result<TokenResponse>> CreateEmailConfirmationTokenAsync(string email)
    {
        var user = await _userManager.FindByEmailAsync(email.Trim());
        if (user is null)
        {
            return Result<TokenResponse>.Fail("user_not_found", "User was not found.", 404);
        }

        return Result<TokenResponse>.Ok(new TokenResponse(await _userManager.GenerateEmailConfirmationTokenAsync(user)));
    }

    public async Task<Result> ConfirmEmailAsync(ConfirmEmailRequest request)
    {
        var user = await _userManager.FindByIdAsync(request.UserId);
        if (user is null)
        {
            return Result.Fail("user_not_found", "User was not found.", 404);
        }

        var result = await _userManager.ConfirmEmailAsync(user, request.Token);
        return result.Succeeded
            ? Result.Ok()
            : Result.Fail("identity_error", string.Join(" ", result.Errors.Select(x => x.Description)), 400);
    }

    public async Task<Result<TokenResponse>> CreatePasswordResetTokenAsync(ForgotPasswordRequest request)
    {
        var user = await _userManager.FindByEmailAsync(request.Email.Trim());
        if (user is null)
        {
            return Result<TokenResponse>.Fail("user_not_found", "User was not found.", 404);
        }

        return Result<TokenResponse>.Ok(new TokenResponse(await _userManager.GeneratePasswordResetTokenAsync(user)));
    }

    public async Task<Result> ResetPasswordAsync(ResetPasswordRequest request)
    {
        var user = await _userManager.FindByEmailAsync(request.Email.Trim());
        if (user is null)
        {
            return Result.Fail("user_not_found", "User was not found.", 404);
        }

        var result = await _userManager.ResetPasswordAsync(user, request.Token, request.NewPassword);
        return result.Succeeded
            ? Result.Ok()
            : Result.Fail("identity_error", string.Join(" ", result.Errors.Select(x => x.Description)), 400);
    }

    private async Task<AuthResponse> CreateAuthResponseAsync(ApplicationUser user)
    {
        var rawRefreshToken = TokenHasher.CreateRawToken();
        _dbContext.RefreshTokens.Add(new RefreshToken
        {
            Id = Guid.NewGuid(),
            UserId = user.Id,
            TokenHash = TokenHasher.Hash(rawRefreshToken),
            ExpiresAtUtc = DateTime.UtcNow.AddDays(_jwtOptions.RefreshTokenExpiresDays)
        });
        await _dbContext.SaveChangesAsync();

        return new AuthResponse(_jwtTokenService.CreateAccessToken(user), rawRefreshToken, ToUserResponse(user));
    }

    private static UserResponse ToUserResponse(ApplicationUser user)
    {
        return new UserResponse(user.Id, user.UserName ?? string.Empty, user.Email ?? string.Empty, user.EmailConfirmed);
    }
}
