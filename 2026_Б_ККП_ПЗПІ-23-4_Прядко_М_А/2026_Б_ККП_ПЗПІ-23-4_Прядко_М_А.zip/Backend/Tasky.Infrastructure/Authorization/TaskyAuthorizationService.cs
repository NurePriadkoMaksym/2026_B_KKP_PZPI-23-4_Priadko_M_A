using Microsoft.EntityFrameworkCore;
using Tasky.Application.Authorization;
using Tasky.Domain;
using Tasky.Infrastructure.Data;

namespace Tasky.Infrastructure.Authorization;

internal sealed class TaskyAuthorizationService : ITaskyAuthorizationService
{
    private readonly ApplicationDbContext _dbContext;

    public TaskyAuthorizationService(ApplicationDbContext dbContext)
    {
        _dbContext = dbContext;
    }

    public Task<bool> IsTeamMemberAsync(Guid teamId, string userId)
    {
        return _dbContext.TeamMembers.AnyAsync(x => x.TeamId == teamId && x.UserId == userId);
    }

    public Task<bool> IsTeamManagerAsync(Guid teamId, string userId)
    {
        return _dbContext.TeamMembers.AnyAsync(x =>
            x.TeamId == teamId &&
            x.UserId == userId &&
            (x.Role == TeamRole.Manager || x.Role == TeamRole.Owner));
    }

    public Task<bool> IsTeamOwnerAsync(Guid teamId, string userId)
    {
        return _dbContext.TeamMembers.AnyAsync(x => x.TeamId == teamId && x.UserId == userId && x.Role == TeamRole.Owner);
    }

    public async Task<bool> CanAccessProjectAsync(Guid projectId, string userId)
    {
        var teamId = await _dbContext.Projects
            .Where(x => x.Id == projectId)
            .Select(x => (Guid?)x.TeamId)
            .SingleOrDefaultAsync();

        return teamId is not null && await IsTeamMemberAsync(teamId.Value, userId);
    }

    public async Task<bool> CanManageProjectAsync(Guid projectId, string userId)
    {
        var teamId = await _dbContext.Projects
            .Where(x => x.Id == projectId)
            .Select(x => (Guid?)x.TeamId)
            .SingleOrDefaultAsync();

        return teamId is not null && await IsTeamManagerAsync(teamId.Value, userId);
    }

    public async Task<bool> CanAccessTaskAsync(Guid taskId, string userId)
    {
        var teamId = await _dbContext.TaskItems
            .Where(x => x.Id == taskId)
            .Select(x => (Guid?)x.Project!.TeamId)
            .SingleOrDefaultAsync();

        return teamId is not null && await IsTeamMemberAsync(teamId.Value, userId);
    }

    public async Task<TeamRole?> GetTeamRoleAsync(Guid teamId, string userId)
    {
        return await _dbContext.TeamMembers
            .Where(x => x.TeamId == teamId && x.UserId == userId)
            .Select(x => (TeamRole?)x.Role)
            .SingleOrDefaultAsync();
    }
}
