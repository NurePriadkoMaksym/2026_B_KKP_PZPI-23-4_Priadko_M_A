using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Tasky.Application.Authorization;
using Tasky.Application.Auth;
using Tasky.Application.Emails;
using Tasky.Application.Projects;
using Tasky.Application.Tasks;
using Tasky.Application.Teams;
using Tasky.Infrastructure.Auth;
using Tasky.Infrastructure.Authorization;
using Tasky.Infrastructure.Data;
using Tasky.Infrastructure.Emails;
using Tasky.Infrastructure.Identity;
using Tasky.Infrastructure.Projects;
using Tasky.Infrastructure.Tasks;
using Tasky.Infrastructure.Teams;

namespace Tasky.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.Configure<JwtOptions>(configuration.GetSection("Jwt"));
        services.Configure<EmailOptions>(configuration.GetSection("Email"));
        services.Configure<InvitationOptions>(configuration.GetSection("Invitations"));

        services.AddDbContext<ApplicationDbContext>(options =>
            options.UseSqlServer(configuration.GetConnectionString("DefaultConnection")));

        services
            .AddIdentityCore<ApplicationUser>(options =>
            {
                options.User.RequireUniqueEmail = true;
                options.Password.RequiredLength = 8;
                options.Password.RequireNonAlphanumeric = false;
                options.SignIn.RequireConfirmedEmail = false;
            })
            .AddEntityFrameworkStores<ApplicationDbContext>()
            .AddSignInManager()
            .AddDefaultTokenProviders();

        services.AddScoped<JwtTokenService>();
        services.AddScoped<IEmailSender, SmtpEmailSender>();
        services.AddScoped<IInvitationEmailService, InvitationEmailService>();
        services.AddScoped<ITaskyAuthorizationService, TaskyAuthorizationService>();
        services.AddScoped<IAuthService, AuthService>();
        services.AddScoped<ITeamService, TeamService>();
        services.AddScoped<IProjectService, ProjectService>();
        services.AddScoped<ITaskService, TaskService>();

        return services;
    }
}
