using System.Net;
using Microsoft.Extensions.Options;
using Tasky.Application.Emails;

namespace Tasky.Infrastructure.Emails;

internal sealed class InvitationEmailService : IInvitationEmailService
{
    private readonly IEmailSender _emailSender;
    private readonly InvitationOptions _options;

    public InvitationEmailService(IEmailSender emailSender, IOptions<InvitationOptions> options)
    {
        _emailSender = emailSender;
        _options = options.Value;
    }

    public async Task<InvitationEmailDeliveryResult> SendTeamInvitationAsync(
        string recipientEmail,
        string teamName,
        string rawToken,
        DateTime expiresAtUtc,
        CancellationToken cancellationToken = default)
    {
        var invitationLink = BuildInvitationLink(rawToken);
        var safeTeamName = WebUtility.HtmlEncode(teamName);
        var safeInvitationLink = WebUtility.HtmlEncode(invitationLink);

        var message = new EmailMessage(
            recipientEmail,
            $"You were invited to join {teamName} on Tasky",
            $"""
            You were invited to join the "{teamName}" team on Tasky.

            Accept the invitation:
            {invitationLink}

            This invitation expires at {expiresAtUtc:O}.
            """,
            $"""
            <p>You were invited to join the <strong>{safeTeamName}</strong> team on Tasky.</p>
            <p><a href="{safeInvitationLink}">Accept invitation</a></p>
            <p>This invitation expires at {expiresAtUtc:O}.</p>
            """);

        var delivery = await _emailSender.SendAsync(message, cancellationToken);
        return new InvitationEmailDeliveryResult(invitationLink, delivery);
    }

    private string BuildInvitationLink(string rawToken)
    {
        var baseUrl = _options.FrontendBaseUrl.TrimEnd('/');
        var path = _options.AcceptInvitationPath.StartsWith('/')
            ? _options.AcceptInvitationPath
            : "/" + _options.AcceptInvitationPath;

        return $"{baseUrl}{path}?token={Uri.EscapeDataString(rawToken)}";
    }
}
