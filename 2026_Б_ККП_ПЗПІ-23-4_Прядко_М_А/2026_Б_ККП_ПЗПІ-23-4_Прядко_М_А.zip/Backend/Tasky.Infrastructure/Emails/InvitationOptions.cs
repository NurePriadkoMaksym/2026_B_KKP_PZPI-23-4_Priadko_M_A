namespace Tasky.Infrastructure.Emails;

public sealed class InvitationOptions
{
    public required string FrontendBaseUrl { get; set; }
    public string AcceptInvitationPath { get; set; } = "/invitations/accept";
}
