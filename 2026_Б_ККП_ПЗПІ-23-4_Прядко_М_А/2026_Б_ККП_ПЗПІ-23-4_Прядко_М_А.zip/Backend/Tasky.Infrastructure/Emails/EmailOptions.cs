namespace Tasky.Infrastructure.Emails;

public sealed class EmailOptions
{
    public bool EnableSmtp { get; set; }
    public required string FromEmail { get; set; }
    public string FromName { get; set; } = "Tasky";
    public string? Host { get; set; }
    public int Port { get; set; } = 587;
    public bool UseSsl { get; set; } = true;
    public string? UserName { get; set; }
    public string? Password { get; set; }
}
