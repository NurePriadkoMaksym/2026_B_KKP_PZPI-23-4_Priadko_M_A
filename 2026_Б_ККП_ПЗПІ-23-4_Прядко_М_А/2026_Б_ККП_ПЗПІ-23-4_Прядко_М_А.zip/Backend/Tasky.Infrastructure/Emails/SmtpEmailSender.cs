using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Tasky.Application.Emails;

namespace Tasky.Infrastructure.Emails;

internal sealed class SmtpEmailSender : IEmailSender
{
    private readonly EmailOptions _options;
    private readonly ILogger<SmtpEmailSender> _logger;

    public SmtpEmailSender(IOptions<EmailOptions> options, ILogger<SmtpEmailSender> logger)
    {
        _options = options.Value;
        _logger = logger;
    }

    public async Task<EmailDeliveryResult> SendAsync(EmailMessage message, CancellationToken cancellationToken = default)
    {
        if (!_options.EnableSmtp)
        {
            const string status = "SMTP delivery is disabled. Configure Email:EnableSmtp=true and SMTP settings.";
            _logger.LogWarning("{Status} To: {To}; Subject: {Subject}; Body: {Body}", status, message.To, message.Subject, message.TextBody);
            return new EmailDeliveryResult(false, "smtp_disabled", status);
        }

        if (string.IsNullOrWhiteSpace(_options.Host))
        {
            const string error = "Email:Host is required when SMTP delivery is enabled.";
            _logger.LogError(error);
            return new EmailDeliveryResult(false, "smtp_not_configured", error);
        }

        if (string.IsNullOrWhiteSpace(_options.FromEmail))
        {
            const string error = "Email:FromEmail is required when SMTP delivery is enabled.";
            _logger.LogError(error);
            return new EmailDeliveryResult(false, "smtp_not_configured", error);
        }

        if (string.IsNullOrWhiteSpace(_options.UserName))
        {
            const string error = "Email:UserName is required when SMTP delivery is enabled.";
            _logger.LogError(error);
            return new EmailDeliveryResult(false, "smtp_not_configured", error);
        }

        if (string.IsNullOrWhiteSpace(_options.Password))
        {
            const string error = "Email:Password is required when SMTP delivery is enabled.";
            _logger.LogError(error);
            return new EmailDeliveryResult(false, "smtp_not_configured", error);
        }

        using var mailMessage = new MailMessage
        {
            From = new MailAddress(_options.FromEmail, _options.FromName),
            Subject = message.Subject,
            Body = message.HtmlBody ?? message.TextBody,
            IsBodyHtml = message.HtmlBody is not null
        };
        mailMessage.To.Add(message.To);

        using var smtpClient = new SmtpClient(_options.Host, _options.Port)
        {
            EnableSsl = _options.UseSsl
        };

        smtpClient.Credentials = new NetworkCredential(_options.UserName, _options.Password);

        try
        {
            await smtpClient.SendMailAsync(mailMessage, cancellationToken);
            _logger.LogInformation("Email sent to {To} with subject {Subject}.", message.To, message.Subject);
            return new EmailDeliveryResult(true, "sent");
        }
        catch (SmtpException exception)
        {
            _logger.LogError(exception, "SMTP failed while sending email to {To}.", message.To);
            return new EmailDeliveryResult(false, "smtp_failed", exception.Message);
        }
        catch (InvalidOperationException exception)
        {
            _logger.LogError(exception, "Email sender is misconfigured.");
            return new EmailDeliveryResult(false, "smtp_not_configured", exception.Message);
        }
    }
}
