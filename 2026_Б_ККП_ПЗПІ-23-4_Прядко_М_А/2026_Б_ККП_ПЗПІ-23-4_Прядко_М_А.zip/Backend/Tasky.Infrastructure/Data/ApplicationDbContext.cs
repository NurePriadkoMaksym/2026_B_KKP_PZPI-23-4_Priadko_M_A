using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Tasky.Domain;
using Tasky.Domain.Auth;
using Tasky.Domain.Common;
using Tasky.Domain.Projects;
using Tasky.Domain.Tasks;
using Tasky.Domain.Teams;
using Tasky.Infrastructure.Identity;

namespace Tasky.Infrastructure.Data;

public sealed class ApplicationDbContext : IdentityDbContext<ApplicationUser>
{
    public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options)
    {
    }

    public DbSet<Team> Teams => Set<Team>();
    public DbSet<TeamMember> TeamMembers => Set<TeamMember>();
    public DbSet<TeamInvitation> TeamInvitations => Set<TeamInvitation>();
    public DbSet<Project> Projects => Set<Project>();
    public DbSet<KanbanColumn> KanbanColumns => Set<KanbanColumn>();
    public DbSet<TaskItem> TaskItems => Set<TaskItem>();
    public DbSet<TaskAssignment> TaskAssignments => Set<TaskAssignment>();
    public DbSet<TaskComment> TaskComments => Set<TaskComment>();
    public DbSet<TaskLabel> TaskLabels => Set<TaskLabel>();
    public DbSet<TaskLabelAssignment> TaskLabelAssignments => Set<TaskLabelAssignment>();
    public DbSet<TaskAttachment> TaskAttachments => Set<TaskAttachment>();
    public DbSet<RefreshToken> RefreshTokens => Set<RefreshToken>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        builder.Entity<Team>(entity =>
        {
            entity.HasQueryFilter(x => x.DeletedAtUtc == null);
            entity.Property(x => x.Name).HasMaxLength(120).IsRequired();
            entity.Property(x => x.Description).HasMaxLength(500);
        });

        builder.Entity<TeamMember>(entity =>
        {
            entity.HasQueryFilter(x => x.Team!.DeletedAtUtc == null);
            entity.HasKey(x => new { x.TeamId, x.UserId });
            entity.HasOne(x => x.Team).WithMany(x => x.Members).HasForeignKey(x => x.TeamId);
        });

        builder.Entity<TeamInvitation>(entity =>
        {
            entity.HasQueryFilter(x => x.Team!.DeletedAtUtc == null);
            entity.Property(x => x.TokenHash).HasMaxLength(128).IsRequired();
            entity.Property(x => x.InvitedEmail).HasMaxLength(256);
            entity.Property(x => x.InvitedUserName).HasMaxLength(256);
            entity.HasIndex(x => x.TokenHash).IsUnique();
            entity.HasOne(x => x.Team).WithMany(x => x.Invitations).HasForeignKey(x => x.TeamId);
        });

        builder.Entity<Project>(entity =>
        {
            entity.HasQueryFilter(x => x.DeletedAtUtc == null);
            entity.Property(x => x.Name).HasMaxLength(120).IsRequired();
            entity.Property(x => x.Description).HasMaxLength(500);
            entity.HasOne(x => x.Team).WithMany(x => x.Projects).HasForeignKey(x => x.TeamId);
        });

        builder.Entity<KanbanColumn>(entity =>
        {
            entity.HasQueryFilter(x => x.DeletedAtUtc == null);
            entity.Property(x => x.Name).HasMaxLength(80).IsRequired();
            entity.HasOne(x => x.Project).WithMany(x => x.Columns).HasForeignKey(x => x.ProjectId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<TaskItem>(entity =>
        {
            entity.HasQueryFilter(x => x.DeletedAtUtc == null);
            entity.Property(x => x.Title).HasMaxLength(180).IsRequired();
            entity.Property(x => x.Description).HasMaxLength(2000);
            entity.HasOne(x => x.Project).WithMany(x => x.Tasks).HasForeignKey(x => x.ProjectId).OnDelete(DeleteBehavior.Restrict);
            entity.HasOne(x => x.Column).WithMany(x => x.Tasks).HasForeignKey(x => x.ColumnId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<TaskAssignment>(entity =>
        {
            entity.HasQueryFilter(x => x.TaskItem!.DeletedAtUtc == null);
            entity.HasKey(x => new { x.TaskItemId, x.UserId });
            entity.HasOne(x => x.TaskItem).WithMany(x => x.Assignments).HasForeignKey(x => x.TaskItemId);
        });

        builder.Entity<TaskComment>(entity =>
        {
            entity.HasQueryFilter(x => x.DeletedAtUtc == null);
            entity.Property(x => x.Body).HasMaxLength(4000).IsRequired();
            entity.HasOne(x => x.TaskItem).WithMany(x => x.Comments).HasForeignKey(x => x.TaskItemId);
        });

        builder.Entity<TaskLabel>(entity =>
        {
            entity.HasQueryFilter(x => x.DeletedAtUtc == null);
            entity.Property(x => x.Name).HasMaxLength(40).IsRequired();
            entity.Property(x => x.Color).HasMaxLength(7).IsRequired();
            entity.HasIndex(x => new { x.TeamId, x.Name }).IsUnique();
            entity.HasOne(x => x.Team).WithMany().HasForeignKey(x => x.TeamId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<TaskLabelAssignment>(entity =>
        {
            entity.HasQueryFilter(x => x.TaskItem!.DeletedAtUtc == null && x.TaskLabel!.DeletedAtUtc == null);
            entity.HasKey(x => new { x.TaskItemId, x.TaskLabelId });
            entity.HasOne(x => x.TaskItem).WithMany(x => x.LabelAssignments).HasForeignKey(x => x.TaskItemId);
            entity.HasOne(x => x.TaskLabel).WithMany(x => x.TaskAssignments).HasForeignKey(x => x.TaskLabelId).OnDelete(DeleteBehavior.Restrict);
        });

        builder.Entity<TaskAttachment>(entity =>
        {
            entity.HasQueryFilter(x => x.DeletedAtUtc == null);
            entity.Property(x => x.FileName).HasMaxLength(260).IsRequired();
            entity.Property(x => x.ContentType).HasMaxLength(120).IsRequired();
            entity.Property(x => x.StoragePath).HasMaxLength(1000).IsRequired();
            entity.HasOne(x => x.TaskItem).WithMany(x => x.Attachments).HasForeignKey(x => x.TaskItemId);
        });

        builder.Entity<RefreshToken>(entity =>
        {
            entity.Property(x => x.TokenHash).HasMaxLength(128).IsRequired();
            entity.Property(x => x.ReplacedByTokenHash).HasMaxLength(128);
            entity.HasIndex(x => x.TokenHash).IsUnique();
            entity.HasIndex(x => x.UserId);
        });
    }

    public Task SoftDeleteAsync<T>(T entity, string userId, CancellationToken cancellationToken = default)
        where T : class, ISoftDelete
    {
        entity.DeletedAtUtc = DateTime.UtcNow;
        entity.DeletedByUserId = userId;
        Entry(entity).State = EntityState.Modified;
        return SaveChangesAsync(cancellationToken);
    }
}
