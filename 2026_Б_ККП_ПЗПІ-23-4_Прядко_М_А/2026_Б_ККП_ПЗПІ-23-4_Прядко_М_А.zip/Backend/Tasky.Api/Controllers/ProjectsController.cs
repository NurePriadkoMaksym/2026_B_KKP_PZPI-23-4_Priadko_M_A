using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Tasky.Application.Projects;

namespace Tasky.Api.Controllers;

[ApiController]
[Authorize]
public sealed class ProjectsController : ControllerBase
{
    private readonly IProjectService _projectService;

    public ProjectsController(IProjectService projectService)
    {
        _projectService = projectService;
    }

    [HttpPost("api/teams/{teamId:guid}/projects")]
    public async Task<ActionResult<ProjectResponse>> Create(Guid teamId, CreateProjectRequest request) =>
        this.FromResult(await _projectService.CreateAsync(this.CurrentUserId(), teamId, request));

    [HttpGet("api/teams/{teamId:guid}/projects")]
    public async Task<ActionResult<IReadOnlyList<ProjectResponse>>> GetTeamProjects(Guid teamId) =>
        this.FromResult(await _projectService.GetTeamProjectsAsync(this.CurrentUserId(), teamId));

    [HttpPost("api/projects/{projectId:guid}/columns")]
    public async Task<ActionResult<KanbanColumnResponse>> AddColumn(Guid projectId, CreateKanbanColumnRequest request) =>
        this.FromResult(await _projectService.AddColumnAsync(this.CurrentUserId(), projectId, request));

    [HttpDelete("api/projects/{projectId:guid}")]
    public async Task<ActionResult> Delete(Guid projectId) =>
        this.FromResult(await _projectService.DeleteAsync(this.CurrentUserId(), projectId));
}
