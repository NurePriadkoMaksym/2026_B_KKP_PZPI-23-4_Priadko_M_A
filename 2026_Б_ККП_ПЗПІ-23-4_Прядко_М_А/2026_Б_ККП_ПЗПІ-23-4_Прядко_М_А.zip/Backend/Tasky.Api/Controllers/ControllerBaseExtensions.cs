using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Tasky.Application.Common;

namespace Tasky.Api.Controllers;

public static class ControllerBaseExtensions
{
    public static string CurrentUserId(this ControllerBase controller)
    {
        return controller.User.FindFirstValue(ClaimTypes.NameIdentifier)
            ?? throw new InvalidOperationException("Authenticated user id is missing.");
    }

    public static ActionResult FromResult(this ControllerBase controller, Result result)
    {
        return result.Succeeded
            ? controller.StatusCode(result.StatusCode)
            : controller.Problem(title: result.Error!.Code, detail: result.Error.Message, statusCode: result.StatusCode);
    }

    public static ActionResult<T> FromResult<T>(this ControllerBase controller, Result<T> result)
    {
        return result.Succeeded
            ? controller.StatusCode(result.StatusCode, result.Value)
            : controller.Problem(title: result.Error!.Code, detail: result.Error.Message, statusCode: result.StatusCode);
    }
}
