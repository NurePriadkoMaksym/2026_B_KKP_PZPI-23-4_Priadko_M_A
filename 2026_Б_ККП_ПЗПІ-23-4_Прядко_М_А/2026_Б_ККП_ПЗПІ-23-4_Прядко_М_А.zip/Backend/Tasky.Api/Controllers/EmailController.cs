using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Tasky.Application.Emails;

namespace Tasky.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/email")]
public sealed class EmailController : ControllerBase
{
    private readonly IEmailSender _emailSender;

    public EmailController(IEmailSender emailSender)
    {
        _emailSender = emailSender;
    }

    [HttpPost("test")]
    public async Task<ActionResult<EmailDeliveryResult>> SendTestEmail(SendTestEmailRequest request)
    {
        var result = await _emailSender.SendAsync(new EmailMessage(
            request.To,
            "Tasky email test",
            "Tasky SMTP configuration is working.",
            "<p>Tasky SMTP configuration is working.</p>"));

        return result.Delivered
            ? Ok(result)
            : Problem(title: result.Status, detail: result.Error, statusCode: StatusCodes.Status503ServiceUnavailable);
    }
}
