using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Tasky.Application.Teams;

namespace Tasky.Api.Controllers;

[ApiController]
[Authorize]
[Route("api/teams")]
public sealed class TeamsController : ControllerBase
{
    private readonly ITeamService _teamService;

    public TeamsController(ITeamService teamService)
    {
        _teamService = teamService;
    }

    [HttpPost]
    public async Task<ActionResult<TeamResponse>> Create(CreateTeamRequest request) =>
        this.FromResult(await _teamService.CreateAsync(this.CurrentUserId(), request));

    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<TeamResponse>>> GetMine() =>
        this.FromResult(await _teamService.GetMineAsync(this.CurrentUserId()));

    [HttpGet("{teamId:guid}")]
    public async Task<ActionResult<TeamResponse>> GetById(Guid teamId) =>
        this.FromResult(await _teamService.GetByIdAsync(this.CurrentUserId(), teamId));

    [HttpDelete("{teamId:guid}")]
    public async Task<ActionResult> Delete(Guid teamId) =>
        this.FromResult(await _teamService.DeleteAsync(this.CurrentUserId(), teamId));

    [HttpGet("{teamId:guid}/members")]
    public async Task<ActionResult<IReadOnlyList<TeamMemberResponse>>> GetMembers(Guid teamId) =>
        this.FromResult(await _teamService.GetMembersAsync(this.CurrentUserId(), teamId));

    [HttpPost("{teamId:guid}/invitations")]
    public async Task<ActionResult<InvitationResponse>> Invite(Guid teamId, InviteUserRequest request) =>
        this.FromResult(await _teamService.InviteAsync(this.CurrentUserId(), teamId, request));

    [HttpPost("invitations/accept")]
    public async Task<ActionResult> AcceptInvitation(AcceptInvitationRequest request) =>
        this.FromResult(await _teamService.AcceptInvitationAsync(this.CurrentUserId(), request));

    [HttpGet("invitations/mine")]
    public async Task<ActionResult<IReadOnlyList<PendingInvitationResponse>>> GetMyPendingInvitations() =>
        this.FromResult(await _teamService.GetMyPendingInvitationsAsync(this.CurrentUserId()));

    [HttpPost("invitations/{invitationId:guid}/accept")]
    public async Task<ActionResult> AcceptInvitation(Guid invitationId) =>
        this.FromResult(await _teamService.AcceptInvitationAsync(this.CurrentUserId(), invitationId));

    [HttpPatch("{teamId:guid}/members/{memberUserId}/role")]
    public async Task<ActionResult> ChangeMemberRole(Guid teamId, string memberUserId, ChangeMemberRoleRequest request) =>
        this.FromResult(await _teamService.ChangeMemberRoleAsync(this.CurrentUserId(), teamId, memberUserId, request));

    [HttpDelete("{teamId:guid}/members/{memberUserId}")]
    public async Task<ActionResult> RemoveMember(Guid teamId, string memberUserId) =>
        this.FromResult(await _teamService.RemoveMemberAsync(this.CurrentUserId(), teamId, memberUserId));
}
