using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Tasky.Application.Auth;

namespace Tasky.Api.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController : ControllerBase
{
    private readonly IAuthService _authService;

    public AuthController(IAuthService authService)
    {
        _authService = authService;
    }

    [HttpPost("register")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponse>> Register(RegisterRequest request)
    {
        return this.FromResult(await _authService.RegisterAsync(request));
    }

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponse>> Login(LoginRequest request)
    {
        return this.FromResult(await _authService.LoginAsync(request));
    }

    [HttpPost("refresh")]
    [AllowAnonymous]
    public async Task<ActionResult<AuthResponse>> Refresh(RefreshTokenRequest request)
    {
        return this.FromResult(await _authService.RefreshAsync(request));
    }

    [HttpPost("logout")]
    [Authorize]
    public async Task<ActionResult> Logout(RevokeRefreshTokenRequest request)
    {
        return this.FromResult(await _authService.RevokeRefreshTokenAsync(this.CurrentUserId(), request));
    }

    [HttpPost("email-confirmation-token")]
    [AllowAnonymous]
    public async Task<ActionResult<TokenResponse>> CreateEmailConfirmationToken([FromQuery] string email)
    {
        return this.FromResult(await _authService.CreateEmailConfirmationTokenAsync(email));
    }

    [HttpPost("confirm-email")]
    [AllowAnonymous]
    public async Task<ActionResult> ConfirmEmail(ConfirmEmailRequest request)
    {
        return this.FromResult(await _authService.ConfirmEmailAsync(request));
    }

    [HttpPost("forgot-password")]
    [AllowAnonymous]
    public async Task<ActionResult<TokenResponse>> ForgotPassword(ForgotPasswordRequest request)
    {
        return this.FromResult(await _authService.CreatePasswordResetTokenAsync(request));
    }

    [HttpPost("reset-password")]
    [AllowAnonymous]
    public async Task<ActionResult> ResetPassword(ResetPasswordRequest request)
    {
        return this.FromResult(await _authService.ResetPasswordAsync(request));
    }
}
