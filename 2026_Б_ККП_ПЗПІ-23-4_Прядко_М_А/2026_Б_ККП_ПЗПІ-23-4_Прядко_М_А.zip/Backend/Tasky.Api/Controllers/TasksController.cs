using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Tasky.Application.Tasks;

namespace Tasky.Api.Controllers;

[ApiController]
[Authorize]
public sealed class TasksController : ControllerBase
{
    private readonly ITaskService _taskService;

    public TasksController(ITaskService taskService)
    {
        _taskService = taskService;
    }

    [HttpPost("api/projects/{projectId:guid}/tasks")]
    public async Task<ActionResult<TaskResponse>> Create(Guid projectId, CreateTaskRequest request) =>
        this.FromResult(await _taskService.CreateAsync(this.CurrentUserId(), projectId, request));

    [HttpGet("api/projects/{projectId:guid}/tasks")]
    public async Task<ActionResult<IReadOnlyList<TaskResponse>>> Search(Guid projectId, [FromQuery] TaskSearchRequest request) =>
        this.FromResult(await _taskService.SearchAsync(this.CurrentUserId(), projectId, request));

    [HttpGet("api/projects/{projectId:guid}/tasks/{taskId:guid}")]
    public async Task<ActionResult<TaskResponse>> GetById(Guid projectId, Guid taskId) =>
        this.FromResult(await _taskService.GetByIdAsync(this.CurrentUserId(), projectId, taskId));

    [HttpPatch("api/projects/{projectId:guid}/tasks/{taskId:guid}")]
    public async Task<ActionResult> Update(Guid projectId, Guid taskId, UpdateTaskRequest request) =>
        this.FromResult(await _taskService.UpdateAsync(this.CurrentUserId(), projectId, taskId, request));

    [HttpDelete("api/projects/{projectId:guid}/tasks/{taskId:guid}")]
    public async Task<ActionResult> Delete(Guid projectId, Guid taskId) =>
        this.FromResult(await _taskService.DeleteAsync(this.CurrentUserId(), projectId, taskId));

    [HttpPost("api/projects/{projectId:guid}/tasks/{taskId:guid}/comments")]
    public async Task<ActionResult<TaskCommentResponse>> AddComment(Guid projectId, Guid taskId, CreateTaskCommentRequest request) =>
        this.FromResult(await _taskService.AddCommentAsync(this.CurrentUserId(), projectId, taskId, request));

    [HttpGet("api/projects/{projectId:guid}/tasks/{taskId:guid}/comments")]
    public async Task<ActionResult<IReadOnlyList<TaskCommentResponse>>> GetComments(Guid projectId, Guid taskId) =>
        this.FromResult(await _taskService.GetCommentsAsync(this.CurrentUserId(), projectId, taskId));

    [HttpPost("api/projects/{projectId:guid}/tasks/{taskId:guid}/attachments")]
    public async Task<ActionResult<TaskAttachmentResponse>> AddAttachment(Guid projectId, Guid taskId, CreateTaskAttachmentRequest request) =>
        this.FromResult(await _taskService.AddAttachmentAsync(this.CurrentUserId(), projectId, taskId, request));

    [HttpPost("api/teams/{teamId:guid}/labels")]
    public async Task<ActionResult<TaskLabelResponse>> CreateLabel(Guid teamId, CreateTaskLabelRequest request) =>
        this.FromResult(await _taskService.CreateLabelAsync(this.CurrentUserId(), teamId, request));

    [HttpGet("api/teams/{teamId:guid}/labels")]
    public async Task<ActionResult<IReadOnlyList<TaskLabelResponse>>> GetLabels(Guid teamId) =>
        this.FromResult(await _taskService.GetLabelsAsync(this.CurrentUserId(), teamId));
}
