namespace Tasky.Domain.Common;

public interface ISoftDelete
{
    DateTime? DeletedAtUtc { get; set; }
    string? DeletedByUserId { get; set; }
}
