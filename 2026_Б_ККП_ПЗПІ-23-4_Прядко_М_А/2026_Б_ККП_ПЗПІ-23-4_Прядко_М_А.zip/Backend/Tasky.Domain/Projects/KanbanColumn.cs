using Tasky.Domain.Common;
using Tasky.Domain.Tasks;

namespace Tasky.Domain.Projects;

public sealed class KanbanColumn : ISoftDelete
{
    public Guid Id { get; set; }
    public Guid ProjectId { get; set; }
    public Project? Project { get; set; }
    public required string Name { get; set; }
    public int Position { get; set; }
    public WorkItemStatus MappedStatus { get; set; } = WorkItemStatus.Todo;
    public DateTime? DeletedAtUtc { get; set; }
    public string? DeletedByUserId { get; set; }

    public ICollection<TaskItem> Tasks { get; set; } = [];
}
