using Tasky.Domain.Common;
using Tasky.Domain.Tasks;
using Tasky.Domain.Teams;

namespace Tasky.Domain.Projects;

public sealed class Project : ISoftDelete
{
    public Guid Id { get; set; }
    public Guid TeamId { get; set; }
    public Team? Team { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public required string CreatedByUserId { get; set; }
    public DateTime? DeletedAtUtc { get; set; }
    public string? DeletedByUserId { get; set; }

    public ICollection<KanbanColumn> Columns { get; set; } = [];
    public ICollection<TaskItem> Tasks { get; set; } = [];
}
