using Tasky.Domain.Common;
using Tasky.Domain.Teams;

namespace Tasky.Domain.Tasks;

public sealed class TaskLabel : ISoftDelete
{
    public Guid Id { get; set; }
    public Guid TeamId { get; set; }
    public Team? Team { get; set; }
    public required string Name { get; set; }
    public required string Color { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public required string CreatedByUserId { get; set; }
    public DateTime? DeletedAtUtc { get; set; }
    public string? DeletedByUserId { get; set; }

    public ICollection<TaskLabelAssignment> TaskAssignments { get; set; } = [];
}
