namespace Tasky.Domain.Tasks;

public sealed class TaskLabelAssignment
{
    public Guid TaskItemId { get; set; }
    public TaskItem? TaskItem { get; set; }
    public Guid TaskLabelId { get; set; }
    public TaskLabel? TaskLabel { get; set; }
}
