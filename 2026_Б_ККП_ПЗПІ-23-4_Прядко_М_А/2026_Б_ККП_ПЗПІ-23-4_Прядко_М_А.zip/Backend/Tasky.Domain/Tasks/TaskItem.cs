using Tasky.Domain.Common;
using Tasky.Domain.Projects;

namespace Tasky.Domain.Tasks;

public sealed class TaskItem : ISoftDelete
{
    public Guid Id { get; set; }
    public Guid ProjectId { get; set; }
    public Project? Project { get; set; }
    public Guid ColumnId { get; set; }
    public KanbanColumn? Column { get; set; }
    public required string Title { get; set; }
    public string? Description { get; set; }
    public WorkItemPriority Priority { get; set; } = WorkItemPriority.Medium;
    public WorkItemStatus Status { get; set; } = WorkItemStatus.Todo;
    public DateTime? DeadlineUtc { get; set; }
    public int Position { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public required string CreatedByUserId { get; set; }
    public DateTime? UpdatedAtUtc { get; set; }
    public string? UpdatedByUserId { get; set; }
    public DateTime? DeletedAtUtc { get; set; }
    public string? DeletedByUserId { get; set; }

    public ICollection<TaskAssignment> Assignments { get; set; } = [];
    public ICollection<TaskComment> Comments { get; set; } = [];
    public ICollection<TaskLabelAssignment> LabelAssignments { get; set; } = [];
    public ICollection<TaskAttachment> Attachments { get; set; } = [];
}
