namespace Tasky.Domain.Tasks;

public sealed class TaskAssignment
{
    public Guid TaskItemId { get; set; }
    public TaskItem? TaskItem { get; set; }
    public required string UserId { get; set; }
    public required string AssignedByUserId { get; set; }
    public DateTime AssignedAtUtc { get; set; } = DateTime.UtcNow;
}
