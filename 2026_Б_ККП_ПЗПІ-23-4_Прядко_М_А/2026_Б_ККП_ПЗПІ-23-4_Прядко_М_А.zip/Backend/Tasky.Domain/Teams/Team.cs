using Tasky.Domain.Common;
using Tasky.Domain.Projects;

namespace Tasky.Domain.Teams;

public sealed class Team : ISoftDelete
{
    public Guid Id { get; set; }
    public required string Name { get; set; }
    public string? Description { get; set; }
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public required string CreatedByUserId { get; set; }
    public DateTime? DeletedAtUtc { get; set; }
    public string? DeletedByUserId { get; set; }

    public ICollection<TeamMember> Members { get; set; } = [];
    public ICollection<TeamInvitation> Invitations { get; set; } = [];
    public ICollection<Project> Projects { get; set; } = [];
}
