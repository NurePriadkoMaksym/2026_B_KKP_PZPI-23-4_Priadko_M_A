namespace Tasky.Domain.Teams;

public sealed class TeamMember
{
    public Guid TeamId { get; set; }
    public Team? Team { get; set; }
    public required string UserId { get; set; }
    public TeamRole Role { get; set; } = TeamRole.Member;
    public DateTime JoinedAtUtc { get; set; } = DateTime.UtcNow;
}
