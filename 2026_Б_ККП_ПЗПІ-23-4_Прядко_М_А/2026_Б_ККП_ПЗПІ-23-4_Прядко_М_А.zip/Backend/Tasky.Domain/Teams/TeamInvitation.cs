namespace Tasky.Domain.Teams;

public sealed class TeamInvitation
{
    public Guid Id { get; set; }
    public Guid TeamId { get; set; }
    public Team? Team { get; set; }
    public string? InvitedEmail { get; set; }
    public string? InvitedUserName { get; set; }
    public string? InvitedUserId { get; set; }
    public required string InvitedByUserId { get; set; }
    public required string TokenHash { get; set; }
    public InvitationStatus Status { get; set; } = InvitationStatus.Pending;
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    public DateTime ExpiresAtUtc { get; set; }
    public DateTime? RespondedAtUtc { get; set; }
}
