# Tasky Web

## Run

```bash
npm install
npm run dev
```


