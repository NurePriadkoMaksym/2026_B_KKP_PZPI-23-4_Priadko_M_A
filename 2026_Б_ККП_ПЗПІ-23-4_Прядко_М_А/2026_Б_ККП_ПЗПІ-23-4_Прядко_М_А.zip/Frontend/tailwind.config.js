/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      boxShadow: {
        panel: '0 16px 50px -28px rgb(15 23 42 / 0.45)',
      },
    },
  },
  plugins: [],
};
