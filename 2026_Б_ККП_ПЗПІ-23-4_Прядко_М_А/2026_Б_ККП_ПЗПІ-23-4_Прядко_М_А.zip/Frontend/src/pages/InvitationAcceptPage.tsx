import { CheckCircle2, MailCheck } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import { StatusMessage } from '../components/StatusMessage';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';

type AcceptState = 'accepting' | 'accepted' | 'failed';

export function InvitationAcceptPage() {
  const { accessToken } = useAuth();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const token = searchParams.get('token') ?? '';
  const acceptedRef = useRef(false);
  const [state, setState] = useState<AcceptState>(token ? 'accepting' : 'failed');
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    if (!token) {
      setState('failed');
      setMessage('Invitation token is missing from the link.');
      return;
    }

    if (!accessToken || acceptedRef.current) return;

    acceptedRef.current = true;
    setState('accepting');
    setMessage(null);

    api
      .acceptInvitation(accessToken, { token })
      .then(() => {
        setState('accepted');
        setMessage('Invitation accepted. The team is now available in your workspace.');
      })
      .catch((err) => {
        setState('failed');
        setMessage(err instanceof Error ? err.message : 'Could not accept invitation');
      });
  }, [accessToken, token]);

  return (
    <section className="mx-auto max-w-xl">
      <div className="panel p-6">
        <div className="mb-5 grid h-12 w-12 place-items-center rounded-md bg-teal-100 text-teal-800">
          {state === 'accepted' ? <CheckCircle2 className="h-6 w-6" /> : <MailCheck className="h-6 w-6" />}
        </div>
        <h1 className="text-2xl font-bold">Team invitation</h1>
        <p className="mt-2 text-sm text-slate-500">
          {state === 'accepting'
            ? 'Accepting your invitation...'
            : state === 'accepted'
              ? 'You can continue to your teams.'
              : 'This invite could not be accepted.'}
        </p>

        <div className="mt-5">
          <StatusMessage
            error={state === 'failed' ? message : null}
            info={state === 'accepted' ? message : null}
          />
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          <Link className="btn-primary" to="/">
            View teams
          </Link>
          {state === 'accepted' && (
            <button className="btn-secondary" type="button" onClick={() => navigate(0)}>
              Refresh
            </button>
          )}
        </div>
      </div>
    </section>
  );
}
