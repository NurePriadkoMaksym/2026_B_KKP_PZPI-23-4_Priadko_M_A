import { ArrowRight, LockKeyhole } from 'lucide-react';
import { FormEvent, useState } from 'react';
import { Link, Navigate, useLocation, useNavigate } from 'react-router-dom';
import { StatusMessage } from '../components/StatusMessage';
import { useAuth } from '../context/AuthContext';

type AuthLocationState = {
  from?: {
    pathname?: string;
    search?: string;
  };
};

export function AuthPage({ mode }: { mode: 'login' | 'register' }) {
  const { isAuthenticated, login, register } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const locationState = location.state as AuthLocationState | null;
  const redirectTo = `${locationState?.from?.pathname ?? '/'}${locationState?.from?.search ?? ''}`;

  if (isAuthenticated) {
    return <Navigate to={redirectTo} replace />;
  }

  const submit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setLoading(true);
    const data = new FormData(event.currentTarget);

    try {
      if (mode === 'register') {
        await register(
          String(data.get('userName')),
          String(data.get('email')),
          String(data.get('password')),
        );
      } else {
        await login(String(data.get('userNameOrEmail')), String(data.get('password')));
      }
      navigate(redirectTo);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <main className="grid min-h-screen bg-slate-50 lg:grid-cols-[minmax(0,0.9fr)_minmax(420px,1fr)]">
      <section className="hidden bg-teal-800 px-12 py-10 text-white lg:flex lg:flex-col lg:justify-between">
        <div className="flex items-center gap-3 text-xl font-bold">
          <span className="grid h-10 w-10 place-items-center rounded-md bg-white text-teal-800">T</span>
          Tasky
        </div>
        <div className="max-w-lg">
          <p className="text-sm font-semibold uppercase tracking-wide text-teal-100">Project workspace</p>
          <h1 className="mt-4 text-5xl font-bold leading-tight">Plan team work without losing the thread.</h1>
          <p className="mt-5 text-lg text-teal-50">
            Manage teams, projects, columns, labels, tasks, comments, and assignments from one focused
            interface backed by your Tasky API.
          </p>
        </div>
      </section>

      <section className="flex items-center justify-center px-4 py-10">
        <form className="panel w-full max-w-md p-6" onSubmit={submit}>
          <div className="mb-6">
            <div className="mb-4 grid h-11 w-11 place-items-center rounded-md bg-teal-100 text-teal-800">
              <LockKeyhole className="h-5 w-5" />
            </div>
            <h2 className="text-2xl font-bold">{mode === 'login' ? 'Sign in' : 'Create account'}</h2>
            <p className="mt-1 text-sm text-slate-500">
              {mode === 'login' ? 'Use your Tasky credentials.' : 'Create a Tasky user profile.'}
            </p>
          </div>

          <div className="space-y-4">
            {mode === 'register' && (
              <>
                <label className="block space-y-1">
                  <span className="label">Username</span>
                  <input className="input" name="userName" minLength={3} maxLength={50} required />
                </label>
                <label className="block space-y-1">
                  <span className="label">Email</span>
                  <input className="input" name="email" type="email" required />
                </label>
              </>
            )}
            {mode === 'login' && (
              <label className="block space-y-1">
                <span className="label">Username or email</span>
                <input className="input" name="userNameOrEmail" required />
              </label>
            )}
            <label className="block space-y-1">
              <span className="label">Password</span>
              <input className="input" name="password" type="password" minLength={mode === 'register' ? 8 : 1} required />
            </label>
            <StatusMessage error={error} />
            <button className="btn-primary w-full" disabled={loading} type="submit">
              {loading ? 'Working...' : mode === 'login' ? 'Sign in' : 'Register'}
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>

          <p className="mt-5 text-center text-sm text-slate-500">
            {mode === 'login' ? "Don't have an account? " : 'Already registered? '}
            <Link
              className="font-semibold text-teal-700 hover:text-teal-800"
              state={location.state}
              to={mode === 'login' ? '/register' : '/login'}
            >
              {mode === 'login' ? 'Create one' : 'Sign in'}
            </Link>
          </p>
        </form>
      </section>
    </main>
  );
}
