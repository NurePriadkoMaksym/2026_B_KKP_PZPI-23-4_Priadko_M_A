import { CalendarClock, MessageSquarePlus, Pencil, Save, Tags, Trash2, UsersRound, X } from 'lucide-react';
import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { Link, Navigate, useNavigate, useParams } from 'react-router-dom';
import { EmptyState } from '../components/EmptyState';
import { StatusMessage } from '../components/StatusMessage';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { priorityLabel, priorityTone, statusLabel } from '../lib/constants';
import type { Project, TaskComment, TaskItem, TaskLabel, TeamMember, WorkItemPriority, WorkItemStatus } from '../lib/types';

export function TaskDetailsPage() {
  const { teamId = '', projectId = '', taskId = '' } = useParams();
  const { accessToken } = useAuth();
  const navigate = useNavigate();
  const [project, setProject] = useState<Project | null>(null);
  const [task, setTask] = useState<TaskItem | null>(null);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [labels, setLabels] = useState<TaskLabel[]>([]);
  const [comments, setComments] = useState<TaskComment[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const memberById = useMemo(
    () => new Map(members.map((member) => [member.userId, member])),
    [members],
  );

  const column = project?.columns.find((item) => item.id === task?.columnId);
  const assignees = task?.assigneeUserIds.map((id) => memberById.get(id)).filter((member): member is TeamMember => Boolean(member)) ?? [];

  const load = useCallback(async () => {
    if (!accessToken || !teamId || !projectId || !taskId) return;
    setError(null);
    setNotFound(false);
    try {
      const [projects, nextMembers, nextLabels, tasks, nextComments] = await Promise.all([
        api.projects(accessToken, teamId),
        api.members(accessToken, teamId),
        api.labels(accessToken, teamId),
        api.tasks(accessToken, projectId, { pageSize: 100 }),
        api.comments(accessToken, projectId, taskId),
      ]);
      const nextProject = projects.find((item) => item.id === projectId) ?? null;
      const nextTask = tasks.find((item) => item.id === taskId) ?? null;
      setProject(nextProject);
      setTask(nextTask);
      setMembers(nextMembers);
      setLabels(nextLabels);
      setComments(nextComments);
      setNotFound(!nextProject || !nextTask);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load task');
    }
  }, [accessToken, teamId, projectId, taskId]);

  useEffect(() => {
    void load();
  }, [load]);

  const addComment = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!accessToken || !task) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    try {
      const comment = await api.addComment(accessToken, projectId, task.id, {
        body: String(data.get('body')),
      });
      setComments((current) => [...current, comment]);
      setTask((current) => (current ? { ...current, commentsCount: current.commentsCount + 1 } : current));
      form.reset();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add comment');
    }
  };

  const updateTask = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!accessToken || !task) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    const deadline = String(data.get('deadlineUtc') || '');

    setError(null);
    try {
      await api.updateTask(accessToken, projectId, task.id, {
        columnId: String(data.get('columnId')),
        title: String(data.get('title')),
        description: String(data.get('description') || ''),
        priority: Number(data.get('priority')) as WorkItemPriority,
        status: Number(data.get('status')) as WorkItemStatus,
        deadlineUtc: deadline ? new Date(deadline).toISOString() : null,
        assigneeUserIds: data.getAll('assigneeUserIds').map(String),
        labelIds: data.getAll('labelIds').map(String),
      });
      setIsEditing(false);
      await load();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not update task');
    }
  };

  const deleteTask = async () => {
    if (!accessToken || !task || !window.confirm(`Delete "${task.title}"?`)) return;

    setError(null);
    try {
      await api.deleteTask(accessToken, projectId, task.id);
      navigate(`/teams/${teamId}/projects/${projectId}`, { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not delete task');
    }
  };

  if (notFound) {
    return <Navigate to={`/teams/${teamId}/projects/${projectId}`} replace />;
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Link className="text-sm font-semibold text-teal-700 hover:text-teal-800" to={`/teams/${teamId}/projects/${projectId}`}>
            Back to board
          </Link>
          <h1 className="mt-2 text-2xl font-bold">{task?.title ?? 'Task'}</h1>
          <p className="mt-1 text-sm text-slate-500">{project?.name ?? 'Project'} task details.</p>
        </div>
        {task && (
          <div className="flex gap-2">
            <button className="btn-secondary" type="button" onClick={() => setIsEditing((current) => !current)}>
              {isEditing ? <X className="h-4 w-4" /> : <Pencil className="h-4 w-4" />}
              {isEditing ? 'Cancel' : 'Edit'}
            </button>
            <button className="btn-secondary border-rose-200 text-rose-700 hover:bg-rose-50" type="button" onClick={() => void deleteTask()}>
              <Trash2 className="h-4 w-4" />
              Delete
            </button>
          </div>
        )}
      </div>

      <StatusMessage error={error} />

      {task ? (
        <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
          {isEditing ? (
            <TaskEditForm
              labels={labels}
              members={members}
              project={project}
              task={task}
              onSubmit={updateTask}
            />
          ) : (
            <section className="panel p-6">
              <div className="flex flex-wrap items-center gap-2">
                <span className={`rounded-full px-2.5 py-1 text-xs font-semibold ${priorityTone[task.priority]}`}>
                  {priorityLabel[task.priority]}
                </span>
                <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600">
                  {statusLabel[task.status]}
                </span>
                {column && (
                  <span className="rounded-full bg-teal-50 px-2.5 py-1 text-xs font-semibold text-teal-800">
                    {column.name}
                  </span>
                )}
              </div>

              <div className="mt-6">
                <h2 className="font-semibold">Description</h2>
                <p className="mt-2 whitespace-pre-wrap text-sm text-slate-700">{task.description || 'No description.'}</p>
              </div>

              <div className="mt-6 grid gap-4 sm:grid-cols-2">
                <InfoBlock icon={UsersRound} title="Assignees">
                  {assignees.length > 0 ? (
                    <div className="space-y-2">
                      {assignees.map((member) => (
                        <div key={member.userId}>
                          <p className="font-medium text-slate-800">{member.userName}</p>
                          <p className="text-xs text-slate-500">{member.email}</p>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <span className="text-slate-500">Unassigned</span>
                  )}
                </InfoBlock>
                <InfoBlock icon={CalendarClock} title="Deadline">
                  {task.deadlineUtc ? new Date(task.deadlineUtc).toLocaleString() : <span className="text-slate-500">No deadline</span>}
                </InfoBlock>
                <InfoBlock icon={Tags} title="Labels">
                  {task.labels.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {task.labels.map((label) => (
                        <span className="rounded-full px-2 py-1 text-xs font-semibold text-white" key={label.id} style={{ backgroundColor: label.color }}>
                          {label.name}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-slate-500">No labels</span>
                  )}
                </InfoBlock>
                <InfoBlock icon={MessageSquarePlus} title="Activity">
                  <span>{task.commentsCount} comments</span>
                </InfoBlock>
              </div>
            </section>
          )}

          <aside className="panel p-5">
            <h2 className="flex items-center gap-2 font-semibold">
              <MessageSquarePlus className="h-5 w-5 text-teal-700" />
              Comments
            </h2>
            <div className="mt-4 max-h-[420px] space-y-3 overflow-y-auto">
              {comments.map((comment) => (
                <div className="rounded-md bg-slate-50 p-3 text-sm" key={comment.id}>
                  <p className="text-slate-800">{comment.body}</p>
                  <p className="mt-2 text-xs text-slate-500">{new Date(comment.createdAtUtc).toLocaleString()}</p>
                </div>
              ))}
              {comments.length === 0 && <p className="text-sm text-slate-500">No comments yet.</p>}
            </div>
            <form className="mt-4 space-y-3" onSubmit={addComment}>
              <textarea className="input min-h-24 resize-y" name="body" maxLength={4000} required />
              <button className="btn-secondary w-full" type="submit">
                Add comment
              </button>
            </form>
          </aside>
        </div>
      ) : (
        <EmptyState icon={MessageSquarePlus} title="Loading task" description="Task details are loading." />
      )}
    </div>
  );
}

function TaskEditForm({
  labels,
  members,
  project,
  task,
  onSubmit,
}: {
  labels: TaskLabel[];
  members: TeamMember[];
  project: Project | null;
  task: TaskItem;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
}) {
  const taskLabelIds = new Set(task.labels.map((label) => label.id));

  return (
    <form className="panel space-y-4 p-6" onSubmit={onSubmit}>
      <h2 className="font-semibold">Edit task</h2>
      <label className="block space-y-1">
        <span className="label">Title</span>
        <input className="input" name="title" maxLength={180} defaultValue={task.title} required />
      </label>
      <label className="block space-y-1">
        <span className="label">Description</span>
        <textarea className="input min-h-28 resize-y" name="description" maxLength={2000} defaultValue={task.description ?? ''} />
      </label>
      <div className="grid gap-3 sm:grid-cols-2">
        <label className="block space-y-1">
          <span className="label">Column</span>
          <select className="input" name="columnId" defaultValue={task.columnId}>
            {(project?.columns ?? []).map((column) => (
              <option key={column.id} value={column.id}>
                {column.name}
              </option>
            ))}
          </select>
        </label>
        <label className="block space-y-1">
          <span className="label">Status</span>
          <select className="input" name="status" defaultValue={task.status}>
            <option value={0}>Todo</option>
            <option value={1}>In progress</option>
            <option value={2}>Done</option>
            <option value={3}>Cancelled</option>
          </select>
        </label>
        <label className="block space-y-1">
          <span className="label">Priority</span>
          <select className="input" name="priority" defaultValue={task.priority}>
            <option value={0}>Low</option>
            <option value={1}>Medium</option>
            <option value={2}>High</option>
            <option value={3}>Critical</option>
          </select>
        </label>
        <label className="block space-y-1">
          <span className="label">Deadline</span>
          <input className="input" name="deadlineUtc" type="datetime-local" defaultValue={toDateTimeLocal(task.deadlineUtc)} />
        </label>
      </div>

      <div>
        <span className="label">Assignees</span>
        <div className="mt-2 max-h-44 space-y-2 overflow-y-auto rounded-md border border-slate-200 p-2">
          {members.map((member) => (
            <label
              className="flex cursor-pointer items-center gap-3 rounded-md px-2 py-1.5 text-sm transition hover:bg-slate-50"
              key={member.userId}
            >
              <input
                className="h-4 w-4 rounded border-slate-300 text-teal-700"
                name="assigneeUserIds"
                type="checkbox"
                value={member.userId}
                defaultChecked={task.assigneeUserIds.includes(member.userId)}
              />
              <span className="min-w-0">
                <span className="block truncate font-medium text-slate-800">{member.userName}</span>
                <span className="block truncate text-xs text-slate-500">{member.email}</span>
              </span>
            </label>
          ))}
          {members.length === 0 && <p className="px-2 py-1.5 text-sm text-slate-500">No team members available.</p>}
        </div>
      </div>

      {labels.length > 0 && (
        <div>
          <span className="label">Labels</span>
          <div className="mt-2 flex flex-wrap gap-2">
            {labels.map((label) => (
              <label className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-3 py-1.5 text-sm" key={label.id}>
                <input name="labelIds" type="checkbox" value={label.id} defaultChecked={taskLabelIds.has(label.id)} />
                <span>{label.name}</span>
              </label>
            ))}
          </div>
        </div>
      )}

      <button className="btn-primary" type="submit">
        <Save className="h-4 w-4" />
        Save changes
      </button>
    </form>
  );
}

function toDateTimeLocal(value?: string | null) {
  if (!value) return '';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '';
  const offset = date.getTimezoneOffset() * 60_000;
  return new Date(date.getTime() - offset).toISOString().slice(0, 16);
}

function InfoBlock({
  children,
  icon: Icon,
  title,
}: {
  children: React.ReactNode;
  icon: typeof UsersRound;
  title: string;
}) {
  return (
    <div className="rounded-md border border-slate-200 p-4">
      <h3 className="mb-2 flex items-center gap-2 text-sm font-semibold text-slate-700">
        <Icon className="h-4 w-4 text-teal-700" />
        {title}
      </h3>
      <div className="text-sm text-slate-700">{children}</div>
    </div>
  );
}
