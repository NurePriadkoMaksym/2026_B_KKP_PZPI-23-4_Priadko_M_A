import { Check, MailCheck, Plus, UsersRound } from 'lucide-react';
import { FormEvent, useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { EmptyState } from '../components/EmptyState';
import { StatusMessage } from '../components/StatusMessage';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { roleLabel } from '../lib/constants';
import type { PendingInvitation, Team } from '../lib/types';

export function DashboardPage() {
  const { accessToken } = useAuth();
  const [teams, setTeams] = useState<Team[]>([]);
  const [pendingInvitations, setPendingInvitations] = useState<PendingInvitation[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const loadTeams = useCallback(async () => {
    if (!accessToken) return;
    setLoading(true);
    setError(null);
    try {
      const [nextTeams, nextInvitations] = await Promise.all([
        api.teams(accessToken),
        api.pendingInvitations(accessToken),
      ]);
      setTeams(nextTeams);
      setPendingInvitations(nextInvitations);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load teams');
    } finally {
      setLoading(false);
    }
  }, [accessToken]);

  useEffect(() => {
    void loadTeams();
  }, [loadTeams]);

  const createTeam = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!accessToken) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    try {
      const team = await api.createTeam(accessToken, {
        name: String(data.get('name')),
        description: String(data.get('description') || ''),
      });
      setTeams((current) => [team, ...current]);
      form.reset();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create team');
    }
  };

  const acceptInvitation = async (invitation: PendingInvitation) => {
    if (!accessToken) return;
    setError(null);
    setInfo(null);
    try {
      await api.acceptPendingInvitation(accessToken, invitation.id);
      setPendingInvitations((current) => current.filter((item) => item.id !== invitation.id));
      setInfo(`Invitation to ${invitation.teamName} accepted.`);
      await loadTeams();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not accept invitation');
    }
  };

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_360px]">
      <section>
        <div className="mb-5 flex flex-wrap items-end justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold">Teams</h1>
            <p className="mt-1 text-sm text-slate-500">Choose a workspace or create a new one.</p>
          </div>
        </div>
        <StatusMessage error={error} info={info} />
        {pendingInvitations.length > 0 && (
          <div className="mt-4 space-y-3 rounded-md border border-teal-200 bg-teal-50 p-4">
            <h2 className="flex items-center gap-2 font-semibold text-teal-950">
              <MailCheck className="h-5 w-5" />
              Pending invitations
            </h2>
            <div className="grid gap-3 md:grid-cols-2">
              {pendingInvitations.map((invitation) => (
                <div className="rounded-md border border-teal-200 bg-white p-4" key={invitation.id}>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="font-semibold text-slate-950">{invitation.teamName}</p>
                      <p className="mt-1 text-xs text-slate-500">
                        Expires {new Date(invitation.expiresAtUtc).toLocaleDateString()}
                      </p>
                    </div>
                    <button
                      className="btn-primary shrink-0"
                      type="button"
                      onClick={() => void acceptInvitation(invitation)}
                    >
                      <Check className="h-4 w-4" />
                      Accept
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        <div className="mt-4 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {teams.map((team) => (
            <Link className="panel block p-5 transition hover:-translate-y-0.5 hover:border-teal-300" key={team.id} to={`/teams/${team.id}`}>
              <div className="flex items-start justify-between gap-3">
                <div>
                  <h2 className="font-semibold">{team.name}</h2>
                  <p className="mt-1 line-clamp-2 text-sm text-slate-500">{team.description || 'No description'}</p>
                </div>
                <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600">
                  {roleLabel[team.currentUserRole]}
                </span>
              </div>
              <div className="mt-5 flex items-center gap-2 text-sm text-slate-500">
                <UsersRound className="h-4 w-4" />
                {team.membersCount} members
              </div>
            </Link>
          ))}
        </div>
        {!loading && teams.length === 0 && (
          <div className="mt-4">
            <EmptyState icon={UsersRound} title="No teams yet" description="Create a team to start adding projects and tasks." />
          </div>
        )}
      </section>

      <aside className="panel h-fit p-5">
        <h2 className="font-semibold">Create team</h2>
        <form className="mt-4 space-y-4" onSubmit={createTeam}>
          <label className="block space-y-1">
            <span className="label">Name</span>
            <input className="input" name="name" maxLength={120} required />
          </label>
          <label className="block space-y-1">
            <span className="label">Description</span>
            <textarea className="input min-h-24 resize-y" name="description" maxLength={500} />
          </label>
          <button className="btn-primary w-full" type="submit">
            <Plus className="h-4 w-4" />
            Create team
          </button>
        </form>
      </aside>
    </div>
  );
}
