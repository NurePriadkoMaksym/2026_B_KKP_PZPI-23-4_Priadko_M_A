import { GripVertical, Plus, Search, SquareKanban, UsersRound } from 'lucide-react';
import { DragEvent, FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { EmptyState } from '../components/EmptyState';
import { StatusMessage } from '../components/StatusMessage';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { priorityLabel, priorityTone, statusLabel } from '../lib/constants';
import type { KanbanColumn, Project, TaskItem, TaskLabel, TeamMember, WorkItemPriority, WorkItemStatus } from '../lib/types';

const defaultColumns: Array<{ name: string; mappedStatus: WorkItemStatus }> = [
  { name: 'Todo', mappedStatus: 0 },
  { name: 'In progress', mappedStatus: 1 },
  { name: 'Done', mappedStatus: 2 },
];

export function ProjectPage() {
  const { teamId = '', projectId = '' } = useParams();
  const { accessToken } = useAuth();
  const [project, setProject] = useState<Project | null>(null);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [labels, setLabels] = useState<TaskLabel[]>([]);
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [query, setQuery] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [draggedTaskId, setDraggedTaskId] = useState<string | null>(null);
  const [dragOverColumnId, setDragOverColumnId] = useState<string | null>(null);

  const columns = useMemo<KanbanColumn[]>(
    () => [...(project?.columns ?? [])].sort((a, b) => a.position - b.position),
    [project],
  );
  const memberById = useMemo(
    () => new Map(members.map((member) => [member.userId, member])),
    [members],
  );

  const load = useCallback(async () => {
    if (!accessToken || !teamId || !projectId) return;
    setError(null);
    try {
      const [projects, nextMembers, nextLabels, nextTasks] = await Promise.all([
        api.projects(accessToken, teamId),
        api.members(accessToken, teamId),
        api.labels(accessToken, teamId),
        api.tasks(accessToken, projectId, { pageSize: 100 }),
      ]);
      setProject(projects.find((item) => item.id === projectId) ?? null);
      setMembers(nextMembers);
      setLabels(nextLabels);
      setTasks(nextTasks);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load project');
    }
  }, [accessToken, teamId, projectId]);

  useEffect(() => {
    void load();
  }, [load]);

  const search = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!accessToken) return;
    try {
      setTasks(await api.tasks(accessToken, projectId, { query, pageSize: 100 }));
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not search tasks');
    }
  };

  const addColumn = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!accessToken || !project) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    try {
      const column = await api.addColumn(accessToken, project.id, {
        name: String(data.get('name')),
        position: Number(data.get('position')),
        mappedStatus: Number(data.get('mappedStatus')) as WorkItemStatus,
      });
      setProject({ ...project, columns: [...project.columns, column] });
      form.reset();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not add column');
    }
  };

  const addDefaultColumns = async () => {
    if (!accessToken || !project) return;
    try {
      const created = await Promise.all(
        defaultColumns.map((column, index) =>
          api.addColumn(accessToken, project.id, {
            ...column,
            position: columns.length + index + 1,
          }),
        ),
      );
      setProject({ ...project, columns: [...project.columns, ...created] });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create columns');
    }
  };

  const createTask = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!accessToken || columns.length === 0) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    const labelIds = data.getAll('labelIds').map(String);
    const assigneeUserIds = data.getAll('assigneeUserIds').map(String);
    const deadline = String(data.get('deadlineUtc') || '');
    try {
      const task = await api.createTask(accessToken, projectId, {
        columnId: String(data.get('columnId')),
        title: String(data.get('title')),
        description: String(data.get('description') || ''),
        priority: Number(data.get('priority')) as WorkItemPriority,
        deadlineUtc: deadline ? new Date(deadline).toISOString() : null,
        assigneeUserIds,
        labelIds,
      });
      setTasks((current) => [task, ...current]);
      form.reset();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create task');
    }
  };

  const moveTask = async (task: TaskItem, column: KanbanColumn) => {
    if (!accessToken) return;
    try {
      await api.updateTask(accessToken, projectId, task.id, {
        columnId: column.id,
        status: column.mappedStatus,
      });
      setTasks((current) =>
        current.map((item) =>
          item.id === task.id ? { ...item, columnId: column.id, status: column.mappedStatus } : item,
        ),
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not move task');
    }
  };

  const dragTask = (event: DragEvent<HTMLElement>, task: TaskItem) => {
    setDraggedTaskId(task.id);
    event.dataTransfer.effectAllowed = 'move';
    event.dataTransfer.setData('text/plain', task.id);
  };

  const dropTask = (event: DragEvent<HTMLDivElement>, column: KanbanColumn) => {
    event.preventDefault();
    const taskId = event.dataTransfer.getData('text/plain') || draggedTaskId;
    const task = tasks.find((item) => item.id === taskId);
    setDraggedTaskId(null);
    setDragOverColumnId(null);
    if (!task || task.columnId === column.id) return;
    void moveTask(task, column);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <Link className="text-sm font-semibold text-teal-700 hover:text-teal-800" to={`/teams/${teamId}`}>
            Back to team
          </Link>
          <h1 className="mt-2 text-2xl font-bold">{project?.name ?? 'Project'}</h1>
          <p className="mt-1 text-sm text-slate-500">{project?.description || 'Kanban board and task details.'}</p>
        </div>
        <form className="flex w-full gap-2 sm:w-auto" onSubmit={search}>
          <input className="input min-w-0 sm:w-72" onChange={(event) => setQuery(event.target.value)} placeholder="Search tasks" value={query} />
          <button className="btn-secondary" type="submit">
            <Search className="h-4 w-4" />
          </button>
        </form>
      </div>

      <StatusMessage error={error} />

      {columns.length === 0 ? (
        <div className="panel p-6">
          <EmptyState icon={SquareKanban} title="No columns" description="Add columns before creating tasks." />
          <button className="btn-primary mt-4" type="button" onClick={addDefaultColumns}>
            <Plus className="h-4 w-4" />
            Add default board
          </button>
        </div>
      ) : (
        <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
          <section className="overflow-x-auto pb-2">
            <div className="grid min-w-[760px] auto-cols-fr grid-flow-col gap-4">
              {columns.map((column) => (
                <div
                  className={`rounded-lg border p-3 transition ${
                    dragOverColumnId === column.id
                      ? 'border-teal-300 bg-teal-50'
                      : 'border-slate-200 bg-slate-100/70'
                  }`}
                  key={column.id}
                  onDragOver={(event) => {
                    event.preventDefault();
                    event.dataTransfer.dropEffect = 'move';
                    setDragOverColumnId(column.id);
                  }}
                  onDragLeave={() => setDragOverColumnId((current) => (current === column.id ? null : current))}
                  onDrop={(event) => dropTask(event, column)}
                >
                  <div className="mb-3 flex items-center justify-between">
                    <h2 className="font-semibold">{column.name}</h2>
                    <span className="text-xs font-semibold text-slate-500">{statusLabel[column.mappedStatus]}</span>
                  </div>
                  <div className="space-y-3">
                    {tasks
                      .filter((task) => task.columnId === column.id)
                      .map((task) => (
                        <article
                          className={`rounded-lg border border-slate-200 bg-white p-4 shadow-sm transition ${
                            draggedTaskId === task.id ? 'opacity-60' : ''
                          }`}
                          draggable
                          key={task.id}
                          onDragEnd={() => {
                            setDraggedTaskId(null);
                            setDragOverColumnId(null);
                          }}
                          onDragStart={(event) => dragTask(event, task)}
                        >
                          <div className="flex gap-2">
                            <GripVertical className="mt-0.5 h-4 w-4 shrink-0 cursor-grab text-slate-400" />
                            <Link className="block min-w-0 flex-1 text-left" to={`/teams/${teamId}/projects/${projectId}/tasks/${task.id}`}>
                              <h3 className="font-semibold">{task.title}</h3>
                              {task.description && <p className="mt-1 line-clamp-2 text-sm text-slate-500">{task.description}</p>}
                            </Link>
                          </div>
                          <div className="mt-3 flex flex-wrap items-center gap-2">
                            <span className={`rounded-full px-2 py-1 text-xs font-semibold ${priorityTone[task.priority]}`}>
                              {priorityLabel[task.priority]}
                            </span>
                            {task.labels.map((label) => (
                              <span className="rounded-full px-2 py-1 text-xs font-semibold text-white" key={label.id} style={{ backgroundColor: label.color }}>
                                {label.name}
                              </span>
                            ))}
                          </div>
                          <div className="mt-3 flex items-center justify-between gap-2">
                            <span className="text-xs text-slate-500">{task.commentsCount} comments</span>
                            {task.assigneeUserIds.length > 0 && (
                              <span className="inline-flex min-w-0 items-center gap-1 text-xs text-slate-500">
                                <UsersRound className="h-3.5 w-3.5 shrink-0" />
                                <span className="truncate">{formatAssignees(task.assigneeUserIds, memberById)}</span>
                              </span>
                            )}
                          </div>
                        </article>
                      ))}
                  </div>
                </div>
              ))}
            </div>
          </section>

          <aside className="space-y-4">
            <TaskForm columns={columns} labels={labels} members={members} onSubmit={createTask} />
            <ColumnForm nextPosition={columns.length + 1} onSubmit={addColumn} />
          </aside>
        </div>
      )}
    </div>
  );
}

function formatAssignees(assigneeUserIds: string[], memberById: Map<string, TeamMember>) {
  const names = assigneeUserIds.map((id) => memberById.get(id)?.userName ?? id);
  if (names.length <= 2) {
    return names.join(', ');
  }

  return `${names.slice(0, 2).join(', ')} +${names.length - 2}`;
}

function TaskForm({
  columns,
  labels,
  members,
  onSubmit,
}: {
  columns: KanbanColumn[];
  labels: TaskLabel[];
  members: TeamMember[];
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
}) {
  return (
    <form className="panel space-y-4 p-5" onSubmit={onSubmit}>
      <h2 className="font-semibold">Create task</h2>
      <label className="block space-y-1">
        <span className="label">Title</span>
        <input className="input" name="title" maxLength={180} required />
      </label>
      <label className="block space-y-1">
        <span className="label">Description</span>
        <textarea className="input min-h-20 resize-y" name="description" maxLength={2000} />
      </label>
      <div className="grid grid-cols-2 gap-3">
        <label className="block space-y-1">
          <span className="label">Column</span>
          <select className="input" name="columnId">
            {columns.map((column) => (
              <option key={column.id} value={column.id}>
                {column.name}
              </option>
            ))}
          </select>
        </label>
        <label className="block space-y-1">
          <span className="label">Priority</span>
          <select className="input" name="priority" defaultValue={1}>
            <option value={0}>Low</option>
            <option value={1}>Medium</option>
            <option value={2}>High</option>
            <option value={3}>Critical</option>
          </select>
        </label>
      </div>
      <label className="block space-y-1">
        <span className="label">Deadline</span>
        <input className="input" name="deadlineUtc" type="datetime-local" />
      </label>
      <div>
        <span className="label">Assignees</span>
        {members.length > 0 ? (
          <div className="mt-2 max-h-44 space-y-2 overflow-y-auto rounded-md border border-slate-200 p-2">
            {members.map((member) => (
              <label
                className="flex cursor-pointer items-center gap-3 rounded-md px-2 py-1.5 text-sm transition hover:bg-slate-50"
                key={member.userId}
              >
                <input className="h-4 w-4 rounded border-slate-300 text-teal-700" name="assigneeUserIds" type="checkbox" value={member.userId} />
                <span className="min-w-0">
                  <span className="block truncate font-medium text-slate-800">{member.userName}</span>
                  <span className="block truncate text-xs text-slate-500">{member.email}</span>
                </span>
              </label>
            ))}
          </div>
        ) : (
          <p className="mt-2 rounded-md border border-slate-200 bg-slate-50 px-3 py-2 text-sm text-slate-500">
            No team members available.
          </p>
        )}
      </div>
      {labels.length > 0 && (
        <div>
          <span className="label">Labels</span>
          <div className="mt-2 flex flex-wrap gap-2">
            {labels.map((label) => (
              <label className="inline-flex items-center gap-2 rounded-full border border-slate-200 px-3 py-1.5 text-sm" key={label.id}>
                <input name="labelIds" type="checkbox" value={label.id} />
                <span>{label.name}</span>
              </label>
            ))}
          </div>
        </div>
      )}
      <button className="btn-primary w-full" type="submit">
        <Plus className="h-4 w-4" />
        Add task
      </button>
    </form>
  );
}

function ColumnForm({
  nextPosition,
  onSubmit,
}: {
  nextPosition: number;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
}) {
  return (
    <form className="panel space-y-4 p-5" onSubmit={onSubmit}>
      <h2 className="font-semibold">Add column</h2>
      <input name="position" type="hidden" value={nextPosition} />
      <label className="block space-y-1">
        <span className="label">Name</span>
        <input className="input" name="name" required />
      </label>
      <label className="block space-y-1">
        <span className="label">Mapped status</span>
        <select className="input" name="mappedStatus" defaultValue={0}>
          <option value={0}>Todo</option>
          <option value={1}>In progress</option>
          <option value={2}>Done</option>
          <option value={3}>Cancelled</option>
        </select>
      </label>
      <button className="btn-secondary w-full" type="submit">
        <SquareKanban className="h-4 w-4" />
        Add column
      </button>
    </form>
  );
}
