import { Copy, FolderKanban, LinkIcon, Plus, Tag, Trash2, UserPlus, UsersRound } from 'lucide-react';
import { FormEvent, useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { EmptyState } from '../components/EmptyState';
import { StatusMessage } from '../components/StatusMessage';
import { useAuth } from '../context/AuthContext';
import { api } from '../lib/api';
import { roleLabel } from '../lib/constants';
import type { Invitation, Project, TaskLabel, Team, TeamMember, TeamRole } from '../lib/types';

export function TeamPage() {
  const { teamId = '' } = useParams();
  const { accessToken, user } = useAuth();
  const [team, setTeam] = useState<Team | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [members, setMembers] = useState<TeamMember[]>([]);
  const [labels, setLabels] = useState<TaskLabel[]>([]);
  const [invitation, setInvitation] = useState<Invitation | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [inviteInfo, setInviteInfo] = useState<string | null>(null);

  const canLoad = Boolean(accessToken && teamId);
  const isOwner = team?.currentUserRole === 2;

  const load = useCallback(async () => {
    if (!accessToken || !teamId) return;
    setError(null);
    try {
      const [nextTeam, nextProjects, nextMembers, nextLabels] = await Promise.all([
        api.team(accessToken, teamId),
        api.projects(accessToken, teamId),
        api.members(accessToken, teamId),
        api.labels(accessToken, teamId),
      ]);
      setTeam(nextTeam);
      setProjects(nextProjects);
      setMembers(nextMembers);
      setLabels(nextLabels);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not load team');
    }
  }, [accessToken, teamId]);

  useEffect(() => {
    if (canLoad) {
      void load();
    }
  }, [canLoad, load]);

  const orderedProjects = useMemo(() => [...projects].sort((a, b) => a.name.localeCompare(b.name)), [projects]);

  const createProject = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!accessToken) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    try {
      const project = await api.createProject(accessToken, teamId, {
        name: String(data.get('name')),
        description: String(data.get('description') || ''),
      });
      setProjects((current) => [project, ...current]);
      form.reset();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create project');
    }
  };

  const invite = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!accessToken) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    setError(null);
    setInviteInfo(null);
    try {
      const created = await api.invite(accessToken, teamId, {
        email: String(data.get('email') || ''),
        userName: String(data.get('userName') || ''),
      });
      setInvitation(created);
      setInviteInfo(created.isTargeted ? 'Targeted invitation created.' : 'Reusable invite link created.');
      form.reset();
    } catch (err) {
      setInvitation(null);
      setError(err instanceof Error ? err.message : 'Could not invite user');
    }
  };

  const removeMember = async (member: TeamMember) => {
    if (!accessToken || !isOwner) return;

    setError(null);
    setInviteInfo(null);
    try {
      await api.removeMember(accessToken, teamId, member.userId);
      setMembers((current) => current.filter((item) => item.userId !== member.userId));
      setTeam((current) => current ? { ...current, membersCount: Math.max(0, current.membersCount - 1) } : current);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not remove member');
    }
  };

  const updateMemberRole = async (member: TeamMember, role: TeamRole) => {
    if (!accessToken || !isOwner || member.role === role || member.userId === user?.id) return;

    setError(null);
    setInviteInfo(null);
    const previousRole = member.role;
    setMembers((current) =>
      current.map((item) => (item.userId === member.userId ? { ...item, role } : item)),
    );

    try {
      await api.updateMemberRole(accessToken, teamId, member.userId, { role });
    } catch (err) {
      setMembers((current) =>
        current.map((item) => (item.userId === member.userId ? { ...item, role: previousRole } : item)),
      );
      setError(err instanceof Error ? err.message : 'Could not update member role');
    }
  };

  const createLabel = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!accessToken) return;
    const form = event.currentTarget;
    const data = new FormData(form);
    try {
      const label = await api.createLabel(accessToken, teamId, {
        name: String(data.get('name')),
        color: String(data.get('color')),
      });
      setLabels((current) => [...current, label]);
      form.reset();
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Could not create label');
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <Link className="text-sm font-semibold text-teal-700 hover:text-teal-800" to="/">
          Back to teams
        </Link>
        <h1 className="mt-2 text-2xl font-bold">{team?.name ?? 'Team'}</h1>
        <p className="mt-1 text-sm text-slate-500">{team?.description || 'Projects, members, and labels for this team.'}</p>
      </div>

      <StatusMessage error={error} />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px]">
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="font-semibold">Projects</h2>
            <span className="text-sm text-slate-500">{projects.length} total</span>
          </div>
          <div className="grid gap-4 md:grid-cols-2">
            {orderedProjects.map((project) => (
              <Link className="panel block p-5 transition hover:-translate-y-0.5 hover:border-teal-300" key={project.id} to={`/teams/${teamId}/projects/${project.id}`}>
                <FolderKanban className="h-5 w-5 text-teal-700" />
                <h3 className="mt-4 font-semibold">{project.name}</h3>
                <p className="mt-1 line-clamp-2 text-sm text-slate-500">{project.description || 'No description'}</p>
                <p className="mt-4 text-sm text-slate-500">{project.columns.length} columns</p>
              </Link>
            ))}
          </div>
          {projects.length === 0 && (
            <EmptyState icon={FolderKanban} title="No projects" description="Create the first project for this team." />
          )}

          <div className="panel p-5">
            <h2 className="mb-4 flex items-center gap-2 font-semibold">
              <UsersRound className="h-5 w-5 text-teal-700" />
              Members
            </h2>
            <div className="divide-y divide-slate-100">
              {members.map((member) => (
                <div className="flex items-center justify-between gap-3 py-3" key={member.userId}>
                  <div className="min-w-0">
                    <p className="font-medium">{member.userName}</p>
                    <p className="text-sm text-slate-500">{member.email}</p>
                  </div>
                  <div className="flex shrink-0 items-center gap-2">
                    {isOwner && member.userId !== user?.id ? (
                      <>
                        <select
                          className="input h-9 w-32 py-1 text-sm"
                          aria-label={`Role for ${member.userName}`}
                          value={member.role}
                          onChange={(event) => void updateMemberRole(member, Number(event.target.value) as TeamRole)}
                        >
                          <option value={0}>{roleLabel[0]}</option>
                          <option value={1}>{roleLabel[1]}</option>
                          <option value={2}>{roleLabel[2]}</option>
                        </select>
                        <button
                          className="grid h-9 w-9 place-items-center rounded-md border border-rose-200 text-rose-700 transition hover:bg-rose-50"
                          type="button"
                          aria-label={`Remove ${member.userName}`}
                          title={`Remove ${member.userName}`}
                          onClick={() => void removeMember(member)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </>
                    ) : (
                      <span className="rounded-full bg-slate-100 px-2.5 py-1 text-xs font-semibold text-slate-600">
                        {roleLabel[member.role]}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        <aside className="space-y-4">
          <form className="panel space-y-4 p-5" onSubmit={createProject}>
            <h2 className="font-semibold">Create project</h2>
            <label className="block space-y-1">
              <span className="label">Name</span>
              <input className="input" name="name" maxLength={120} required />
            </label>
            <label className="block space-y-1">
              <span className="label">Description</span>
              <textarea className="input min-h-20 resize-y" name="description" maxLength={500} />
            </label>
            <button className="btn-primary w-full" type="submit">
              <Plus className="h-4 w-4" />
              Create project
            </button>
          </form>

          {isOwner && (
            <form className="panel space-y-4 p-5" onSubmit={invite}>
              <h2 className="font-semibold">Invite member</h2>
              <label className="block space-y-1">
                <span className="label">Email</span>
                <input className="input" name="email" type="email" />
              </label>
              <label className="block space-y-1">
                <span className="label">Username</span>
                <input className="input" name="userName" />
              </label>
              <StatusMessage info={inviteInfo} />
              <button className="btn-secondary w-full" type="submit">
                <UserPlus className="h-4 w-4" />
                Send invite
              </button>
              {invitation && (
                <div className="space-y-2 rounded-md border border-teal-200 bg-teal-50 p-3 text-sm text-teal-900">
                  <div className="flex items-center gap-2 font-semibold">
                    <LinkIcon className="h-4 w-4" />
                    Invite link ready
                  </div>
                  <p className="break-all text-xs text-teal-800">{invitation.invitationLink}</p>
                  <button
                    className="btn-secondary w-full"
                    type="button"
                    onClick={() => void navigator.clipboard.writeText(invitation.invitationLink)}
                  >
                    <Copy className="h-4 w-4" />
                    Copy invite link
                  </button>
                </div>
              )}
            </form>
          )}

          <form className="panel space-y-4 p-5" onSubmit={createLabel}>
            <h2 className="font-semibold">Create label</h2>
            <div className="grid grid-cols-[1fr_64px] gap-3">
              <label className="block space-y-1">
                <span className="label">Name</span>
                <input className="input" name="name" maxLength={40} required />
              </label>
              <label className="block space-y-1">
                <span className="label">Color</span>
                <input className="input h-10 p-1" name="color" type="color" defaultValue="#0f766e" required />
              </label>
            </div>
            <button className="btn-secondary w-full" type="submit">
              <Tag className="h-4 w-4" />
              Add label
            </button>
            <div className="flex flex-wrap gap-2">
              {labels.map((label) => (
                <span className="rounded-full px-2.5 py-1 text-xs font-semibold text-white" key={label.id} style={{ backgroundColor: label.color }}>
                  {label.name}
                </span>
              ))}
            </div>
          </form>
        </aside>
      </div>
    </div>
  );
}
