import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react';
import { api, setAuthRecovery } from '../lib/api';
import type { AuthResponse, User } from '../lib/types';

type AuthState = {
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
};

type AuthContextValue = AuthState & {
  isAuthenticated: boolean;
  login: (userNameOrEmail: string, password: string) => Promise<void>;
  register: (userName: string, email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
};

const STORAGE_KEY = 'tasky.auth';
const EMPTY_AUTH: AuthState = { user: null, accessToken: null, refreshToken: null };
const AuthContext = createContext<AuthContextValue | undefined>(undefined);

function readAuth(): AuthState {
  const value = localStorage.getItem(STORAGE_KEY);
  if (!value) {
    return EMPTY_AUTH;
  }

  try {
    return JSON.parse(value) as AuthState;
  } catch {
    localStorage.removeItem(STORAGE_KEY);
    return EMPTY_AUTH;
  }
}

function toAuthState(response: AuthResponse): AuthState {
  return {
    user: response.user,
    accessToken: response.accessToken,
    refreshToken: response.refreshToken,
  };
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [state, setState] = useState<AuthState>(readAuth);
  const stateRef = useRef(state);
  const refreshPromiseRef = useRef<Promise<string | null> | null>(null);

  const persist = useCallback((next: AuthState) => {
    stateRef.current = next;
    setState(next);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  }, []);

  const clearAuth = useCallback(() => {
    stateRef.current = EMPTY_AUTH;
    setState(EMPTY_AUTH);
    localStorage.removeItem(STORAGE_KEY);
  }, []);

  useEffect(() => {
    stateRef.current = state;
  }, [state]);

  useEffect(() => {
    setAuthRecovery(async () => {
      const current = stateRef.current;
      if (!current.refreshToken) {
        clearAuth();
        return null;
      }

      refreshPromiseRef.current ??= api
        .refresh({ refreshToken: current.refreshToken })
        .then((response) => {
          const next = toAuthState(response);
          persist(next);
          return next.accessToken;
        })
        .catch(() => {
          clearAuth();
          return null;
        })
        .finally(() => {
          refreshPromiseRef.current = null;
        });

      return refreshPromiseRef.current;
    });

    return () => setAuthRecovery(null);
  }, [clearAuth, persist]);

  const value = useMemo<AuthContextValue>(
    () => ({
      ...state,
      isAuthenticated: Boolean(state.accessToken),
      login: async (userNameOrEmail, password) => {
        persist(toAuthState(await api.login({ userNameOrEmail, password })));
      },
      register: async (userName, email, password) => {
        persist(toAuthState(await api.register({ userName, email, password })));
      },
      logout: async () => {
        if (state.accessToken && state.refreshToken) {
          await api.logout(state.accessToken, state.refreshToken).catch(() => undefined);
        }

        clearAuth();
      },
    }),
    [clearAuth, persist, state],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used inside AuthProvider');
  }

  return context;
}
