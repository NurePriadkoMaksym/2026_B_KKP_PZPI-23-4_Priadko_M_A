export function StatusMessage({
  error,
  info,
}: {
  error?: string | null;
  info?: string | null;
}) {
  if (!error && !info) {
    return null;
  }

  return (
    <div
      className={`rounded-md border px-3 py-2 text-sm ${
        error ? 'border-rose-200 bg-rose-50 text-rose-800' : 'border-teal-200 bg-teal-50 text-teal-800'
      }`}
    >
      {error ?? info}
    </div>
  );
}
