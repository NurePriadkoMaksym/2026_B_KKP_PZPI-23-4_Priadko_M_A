export type TeamRole = 0 | 1 | 2;
export type WorkItemPriority = 0 | 1 | 2 | 3;
export type WorkItemStatus = 0 | 1 | 2 | 3;

export type User = {
  id: string;
  userName: string;
  email: string;
  emailConfirmed: boolean;
};

export type AuthResponse = {
  accessToken: string;
  refreshToken: string;
  user: User;
};

export type Team = {
  id: string;
  name: string;
  description?: string | null;
  currentUserRole: TeamRole;
  membersCount: number;
};

export type TeamMember = {
  userId: string;
  userName: string;
  email: string;
  role: TeamRole;
  joinedAtUtc: string;
};

export type Invitation = {
  id: string;
  teamId: string;
  invitedUserName?: string | null;
  invitedEmail?: string | null;
  status: number;
  expiresAtUtc: string;
  token: string;
  invitationLink: string;
  isTargeted: boolean;
};

export type PendingInvitation = {
  id: string;
  teamId: string;
  teamName: string;
  invitedByUserId: string;
  createdAtUtc: string;
  expiresAtUtc: string;
};

export type Project = {
  id: string;
  teamId: string;
  name: string;
  description?: string | null;
  columns: KanbanColumn[];
};

export type KanbanColumn = {
  id: string;
  name: string;
  position: number;
  mappedStatus: WorkItemStatus;
};

export type TaskLabel = {
  id: string;
  name: string;
  color: string;
};

export type TaskItem = {
  id: string;
  projectId: string;
  columnId: string;
  title: string;
  description?: string | null;
  priority: WorkItemPriority;
  status: WorkItemStatus;
  deadlineUtc?: string | null;
  assigneeUserIds: string[];
  labels: TaskLabel[];
  commentsCount: number;
  attachmentsCount: number;
  createdAtUtc: string;
  updatedAtUtc?: string | null;
};

export type TaskComment = {
  id: string;
  taskItemId: string;
  authorUserId: string;
  body: string;
  createdAtUtc: string;
  editedAtUtc?: string | null;
};
