import type { TeamRole, WorkItemPriority, WorkItemStatus } from './types';

export const API_BASE_URL =
  import.meta.env.VITE_API_BASE_URL?.replace(/\/$/, '') ?? '';

export const roleLabel: Record<TeamRole, string> = {
  0: 'Member',
  1: 'Manager',
  2: 'Owner',
};

export const priorityLabel: Record<WorkItemPriority, string> = {
  0: 'Low',
  1: 'Medium',
  2: 'High',
  3: 'Critical',
};

export const statusLabel: Record<WorkItemStatus, string> = {
  0: 'Todo',
  1: 'In progress',
  2: 'Done',
  3: 'Cancelled',
};

export const priorityTone: Record<WorkItemPriority, string> = {
  0: 'bg-slate-100 text-slate-700',
  1: 'bg-sky-100 text-sky-800',
  2: 'bg-amber-100 text-amber-800',
  3: 'bg-rose-100 text-rose-800',
};
