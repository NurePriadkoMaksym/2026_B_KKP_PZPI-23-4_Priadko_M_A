import { API_BASE_URL } from './constants';
import type {
  AuthResponse,
  Invitation,
  KanbanColumn,
  PendingInvitation,
  Project,
  TaskComment,
  TaskItem,
  TaskLabel,
  Team,
  TeamMember,
  WorkItemPriority,
  WorkItemStatus,
} from './types';

type RequestOptions = {
  token?: string | null;
  method?: string;
  body?: unknown;
  query?: Record<string, string | number | undefined | null>;
  skipAuthRetry?: boolean;
};

type AuthRecovery = () => Promise<string | null>;

let authRecovery: AuthRecovery | null = null;

export function setAuthRecovery(nextAuthRecovery: AuthRecovery | null) {
  authRecovery = nextAuthRecovery;
}

export class ApiError extends Error {
  status: number;

  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

async function send<T>(path: string, options: RequestOptions): Promise<T> {
  const baseUrl = API_BASE_URL || window.location.origin;
  const url = new URL(`${API_BASE_URL}${path}`, baseUrl);

  Object.entries(options.query ?? {}).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '') {
      url.searchParams.set(key, String(value));
    }
  });

  const response = await fetch(url, {
    method: options.method ?? 'GET',
    headers: {
      Accept: 'application/json',
      ...(options.body ? { 'Content-Type': 'application/json' } : {}),
      ...(options.token ? { Authorization: `Bearer ${options.token}` } : {}),
    },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  const contentType = response.headers.get('content-type') ?? '';
  const payload = response.status === 204 || !contentType.includes('application/json')
    ? null
    : await response.json();

  if (!response.ok) {
    throw new ApiError(response.status, payload?.detail ?? payload?.title ?? 'Request failed');
  }

  return payload as T;
}

async function request<T>(path: string, options: RequestOptions = {}): Promise<T> {
  try {
    return await send<T>(path, options);
  } catch (err) {
    if (
      err instanceof ApiError &&
      err.status === 401 &&
      options.token &&
      !options.skipAuthRetry &&
      authRecovery
    ) {
      const refreshedToken = await authRecovery();
      if (refreshedToken) {
        return send<T>(path, {
          ...options,
          token: refreshedToken,
          skipAuthRetry: true,
        });
      }
    }

    throw err;
  }
}

export const api = {
  register: (body: { userName: string; email: string; password: string }) =>
    request<AuthResponse>('/api/auth/register', { method: 'POST', body }),
  login: (body: { userNameOrEmail: string; password: string }) =>
    request<AuthResponse>('/api/auth/login', { method: 'POST', body }),
  refresh: (body: { refreshToken: string }) =>
    request<AuthResponse>('/api/auth/refresh', { method: 'POST', body, skipAuthRetry: true }),
  logout: (token: string, refreshToken: string) =>
    request<void>('/api/auth/logout', {
      token,
      method: 'POST',
      body: { refreshToken },
      skipAuthRetry: true,
    }),
  teams: (token: string) => request<Team[]>('/api/teams', { token }),
  createTeam: (token: string, body: { name: string; description?: string }) =>
    request<Team>('/api/teams', { token, method: 'POST', body }),
  team: (token: string, teamId: string) => request<Team>(`/api/teams/${teamId}`, { token }),
  members: (token: string, teamId: string) =>
    request<TeamMember[]>(`/api/teams/${teamId}/members`, { token }),
  updateMemberRole: (token: string, teamId: string, memberUserId: string, body: { role: TeamMember['role'] }) =>
    request<void>(`/api/teams/${teamId}/members/${memberUserId}/role`, { token, method: 'PATCH', body }),
  removeMember: (token: string, teamId: string, memberUserId: string) =>
    request<void>(`/api/teams/${teamId}/members/${memberUserId}`, { token, method: 'DELETE' }),
  invite: (token: string, teamId: string, body: { userName?: string; email?: string }) =>
    request<Invitation>(`/api/teams/${teamId}/invitations`, { token, method: 'POST', body }),
  acceptInvitation: (token: string, body: { token: string }) =>
    request<void>('/api/teams/invitations/accept', { token, method: 'POST', body }),
  pendingInvitations: (token: string) =>
    request<PendingInvitation[]>('/api/teams/invitations/mine', { token }),
  acceptPendingInvitation: (token: string, invitationId: string) =>
    request<void>(`/api/teams/invitations/${invitationId}/accept`, { token, method: 'POST' }),
  projects: (token: string, teamId: string) =>
    request<Project[]>(`/api/teams/${teamId}/projects`, { token }),
  createProject: (token: string, teamId: string, body: { name: string; description?: string }) =>
    request<Project>(`/api/teams/${teamId}/projects`, { token, method: 'POST', body }),
  addColumn: (
    token: string,
    projectId: string,
    body: { name: string; position: number; mappedStatus: WorkItemStatus },
  ) => request<KanbanColumn>(`/api/projects/${projectId}/columns`, { token, method: 'POST', body }),
  tasks: (
    token: string,
    projectId: string,
    query?: {
      query?: string;
      priority?: WorkItemPriority;
      status?: WorkItemStatus;
      labelId?: string;
      page?: number;
      pageSize?: number;
    },
  ) => request<TaskItem[]>(`/api/projects/${projectId}/tasks`, { token, query }),
  createTask: (
    token: string,
    projectId: string,
    body: {
      columnId: string;
      title: string;
      description?: string;
      priority: WorkItemPriority;
      deadlineUtc?: string | null;
      assigneeUserIds: string[];
      labelIds: string[];
    },
  ) => request<TaskItem>(`/api/projects/${projectId}/tasks`, { token, method: 'POST', body }),
  updateTask: (
    token: string,
    projectId: string,
    taskId: string,
    body: Partial<{
      columnId: string;
      title: string;
      description: string;
      priority: WorkItemPriority;
      status: WorkItemStatus;
      deadlineUtc: string | null;
      assigneeUserIds: string[];
      labelIds: string[];
    }>,
  ) => request<void>(`/api/projects/${projectId}/tasks/${taskId}`, { token, method: 'PATCH', body }),
  deleteTask: (token: string, projectId: string, taskId: string) =>
    request<void>(`/api/projects/${projectId}/tasks/${taskId}`, { token, method: 'DELETE' }),
  comments: (token: string, projectId: string, taskId: string) =>
    request<TaskComment[]>(`/api/projects/${projectId}/tasks/${taskId}/comments`, { token }),
  addComment: (token: string, projectId: string, taskId: string, body: { body: string }) =>
    request<TaskComment>(`/api/projects/${projectId}/tasks/${taskId}/comments`, {
      token,
      method: 'POST',
      body,
    }),
  labels: (token: string, teamId: string) => request<TaskLabel[]>(`/api/teams/${teamId}/labels`, { token }),
  createLabel: (token: string, teamId: string, body: { name: string; color: string }) =>
    request<TaskLabel>(`/api/teams/${teamId}/labels`, { token, method: 'POST', body }),
};
